# tenure batch
Batch program that prepopulates customer relationship start/expiry dates in the loy_relationship table prior to CRODS -> CMDM NRMASILVER customer migration.
