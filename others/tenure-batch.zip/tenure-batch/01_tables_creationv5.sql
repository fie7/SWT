create table temp.processed_party_group (
  party_grp_id integer not null primary key
);

create table temp.batch_run (
  id integer generated always as identity primary key
  , max_txn_time timestamp not null
  , start_time timestamp not null
  , finish_time timestamp null
  , txn_id integer not null
);

create table temp.warning_type (
  id integer not null
  , description varchar(100) not null
  , primary key (id)
);

create table temp.processing_stage (
  id integer not null
  , description varchar(100) not null
  , primary key (id)
);

create table temp.processed_party_group_batch_run (
  id integer generated always as identity primary key
  , party_grp_id integer not null
  , batch_run_id integer not null
  , mdm_id varchar(10) not null
  , request varchar(1000) not null
  , response varchar(1000) not null
  , http_response_status integer not null
  , warning_type_id integer null
  , processing_stage_id integer not null
  , processed_time timestamp not null
  , foreign key (party_grp_id) references temp.processed_party_group(party_grp_id)
  , foreign key (batch_run_id) references temp.batch_run (id)
  , foreign key (warning_type_id) references temp.warning_type (id)
  , foreign key (processing_stage_id) references temp.processing_stage (id)
  , constraint c1 unique (party_grp_id, batch_run_id)
);

insert into temp.warning_type (id, description) values (1, 'Party Group ID non existent in SVx');
insert into temp.warning_type (id, description) values (2, 'NULL CRSD returned in SVx response');

insert into temp.processing_stage (id, description) values (1, 'Red delta');
insert into temp.processing_stage (id, description) values (2, 'Blue delta');
insert into temp.processing_stage (id, description) values (3, 'Retry previous errors');
