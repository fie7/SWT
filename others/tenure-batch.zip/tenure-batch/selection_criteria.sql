-- blue delta:

select
  t.party_grp_id
  , t.mdm_id
  , t.rel_commence_date
  , t.reference_no
  , t.override_reason
  , t.rel_expiry_date
  , t.transaction_id
  , t.tran_timestamp
  , t.ext_ref
from (
  select
    pgc.party_grp_id
    , pc.src_sys_party_id mdm_id
    , lrc.rel_commence_date
    , lrc.reference_no
    , lrc.override_reason
    , lrc.rel_expiry_date
    , t.transaction_id
    , t.tran_timestamp
    , mic.misc_item ext_ref
    , row_number() over (partition by pgc.party_grp_id) row_num
  from
    crods.party_grp_role_current pgrc
    inner join crods.party_group_current pgc
      on (pgrc.party_grp_id = pgc.party_grp_id)
    left outer join temp.processed_party_group ppg
      on (pgc.party_grp_id = ppg.party_grp_id)
    inner join crods.party_current pc
      on (pgrc.party_link_id = pc.party_link_id)
        and (pc.legal_entity_cde = 'NRMASILVER')
        and (pc.src_sys_name_cde = 'MDM')
    left outer join crods.loy_relationship_current lrc
      on (pgc.party_grp_id = lrc.party_grp_id)
    left outer join crods.transaction t
      on (lrc.transaction_id = t.transaction_id)
    left outer join crods.misc_item_current mic
      on (pc.party_link_id = mic.party_link_id)
        and (mic.misc_item_type_cde = 'PTYEXTREF')  -- pick up party external reference if any
  where
    (ppg.party_grp_id is null)  -- haven't been processed
) t
where
  (t.row_num = 1)  -- pick any one of the MDM IDs belonging to the same group
