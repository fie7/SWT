package au.com.iag.customer.tenure.api.model;

import java.time.LocalDate;
import java.time.ZonedDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerRelationship {

    private LocalDate relationship_commencement_date;

    private String reference_number;

    private String relationship_override_reason;

    private LocalDate relationship_expirydate;

    private String source_system;

    private String relationship_transaction_id;
    
    //@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    //@JsonDeserialize(using = LocalDateTimeDeserializer.class)
    //@JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "uuuu-MM-dd'T'HH:mm:ss.SSSXXXX")
    private ZonedDateTime transaction_timestamp;
    
    /*
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "uuuu-MM-dd'T'HH:mm:ss.SSSXXXX")
    public ZonedDateTime test() {
        return transaction_timestamp.atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneOffset.UTC);
    }
    */

}
