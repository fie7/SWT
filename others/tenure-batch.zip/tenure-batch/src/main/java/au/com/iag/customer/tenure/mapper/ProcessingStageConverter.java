package au.com.iag.customer.tenure.mapper;

import static au.com.iag.customer.tenure.domain.ProcessingStage.values;
import static java.util.Optional.ofNullable;
import static java.util.stream.Stream.of;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import au.com.iag.customer.tenure.domain.ProcessingStage;

@Converter(autoApply = true)
public class ProcessingStageConverter implements AttributeConverter<ProcessingStage, Integer> {
 
    @Override
    public Integer convertToDatabaseColumn(ProcessingStage processingStage) {
        if (processingStage == null) {
            return null;
        }
        return processingStage.getId();
    }

    @Override
    public ProcessingStage convertToEntityAttribute(Integer id) {
        return ofNullable(id).map(i -> of(values()).filter(i::equals).findFirst().orElseThrow(IllegalArgumentException::new)).orElseGet(() -> null);
    }
}