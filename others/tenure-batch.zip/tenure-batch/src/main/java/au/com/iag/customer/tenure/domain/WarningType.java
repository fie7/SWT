package au.com.iag.customer.tenure.domain;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum WarningType {
    GROUP_NON_EXISTENT(1), NULL_CRSD(2);

    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
 
}
