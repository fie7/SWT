package au.com.iag.customer.tenure.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtil {
	public static Date localDateToDate(LocalDate ld) {
		return new GregorianCalendar(ld.getYear(), ld.getMonthValue() - 1, ld.getDayOfMonth()).getTime();
	}

	public static LocalDate calendarToLocalDate(Calendar cal) {
		return LocalDate.of(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
	}

	public static LocalDate dateToLocalDate(Date d) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		return calendarToLocalDate(cal);
	}

	public static Date localDateTimeToDate(LocalDateTime ldt) {
		return new GregorianCalendar(ldt.getYear(), ldt.getMonthValue() - 1, ldt.getDayOfMonth(), ldt.getHour(), ldt.getMinute(), ldt.getSecond()).getTime();
	}

	public static LocalDateTime calendarToLocalDateTime(Calendar cal) {
		return LocalDateTime.of(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
	}

	public static LocalDateTime dateToLocalDateTime(Date d) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		return calendarToLocalDateTime(cal);
	}

   public static Date localDateTimeWithMillisToDate(LocalDateTime ldt) {
        Calendar cal = new GregorianCalendar(ldt.getYear(), ldt.getMonthValue() - 1, ldt.getDayOfMonth(), ldt.getHour(), ldt.getMinute(), ldt.getSecond());
        cal.set(Calendar.MILLISECOND, ldt.getNano());
        return cal.getTime();
    }

    public static LocalDateTime calendarToLocalDateTimeWithMillis(Calendar cal) {
        return LocalDateTime.of(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND), cal.get(Calendar.MILLISECOND));
    }

    public static LocalDateTime dateToLocalDateTimeWithMillis(Date d) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        return calendarToLocalDateTimeWithMillis(cal);
    }

	public static Date localTimeToDate(LocalTime lt) {
		return new GregorianCalendar(1900, 0, 1, lt.getHour(), lt.getMinute(), lt.getSecond()).getTime();
	}

	public static LocalTime calendarToLocalTime(Calendar cal) {
		return LocalTime.of(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
	}

	public static LocalTime dateToLocalTime(Date d) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		return calendarToLocalTime(cal);
	}
}
