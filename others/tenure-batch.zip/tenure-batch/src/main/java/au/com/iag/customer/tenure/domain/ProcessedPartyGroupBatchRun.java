package au.com.iag.customer.tenure.domain;

import static javax.persistence.GenerationType.IDENTITY;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Entity
@Table(name="processed_party_group_batch_run", schema="temp")
@Data
//@NoArgsConstructor(access = AccessLevel.PRIVATE)
//@RequiredArgsConstructor
@NoArgsConstructor
public class ProcessedPartyGroupBatchRun implements DomainModel {

    @Id
    @GeneratedValue(strategy=IDENTITY)  // if we comment this out, will ask to supply explicit value
    protected Integer id;

    //@Column(name = "party_grp_id", updatable = false, insertable = false)
    @Column(name = "party_grp_id")
    @NonNull
    private Integer partyGroupId;

    /*
    @ManyToOne(optional = false, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "party_grp_id")
    @NonNull
    @EqualsAndHashCode.Exclude
    private ProcessedPartyGroup processedPartyGroup;
    */
    
    @Column(name = "batch_run_id")
    @NonNull
    private int batchRunId;

    @Column(name = "mdm_id")
    @NonNull
    private String mdmId;

    @Column(name = "request")
    @NonNull
    private String request;

    @Column(name = "response")
    @NonNull
    private String response;

    @Column(name = "http_response_status")
    @NonNull
    private int httpResponseStatus;

    @Column(name = "warning_type_id")
    private WarningType warningType;

    @Column(name = "processing_stage_id")
    private ProcessingStage processingStage;

    @Column(name = "processed_time")
    @NonNull
    private Timestamp processedTime;

    public ProcessedPartyGroupBatchRun(@NonNull Integer partyGroupId, /*@NonNull ProcessedPartyGroup processedPartyGroup,*/
            @NonNull int batchRunId, @NonNull String mdmId, @NonNull String request, @NonNull String response,
            @NonNull int httpResponseStatus, WarningType warningType, @NonNull ProcessingStage processingStage, @NonNull Timestamp processedTime) {
        super();
        this.partyGroupId = partyGroupId;
        //this.processedPartyGroup = processedPartyGroup;
        this.batchRunId = batchRunId;
        this.mdmId = mdmId;
        this.request = request;
        this.response = response;
        this.httpResponseStatus = httpResponseStatus;
        this.warningType = warningType;
        this.processingStage = processingStage;
        this.processedTime = processedTime;
    }
}
