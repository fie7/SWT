package au.com.iag.customer.tenure.repository;

import org.springframework.data.repository.CrudRepository;

import au.com.iag.customer.tenure.domain.ProcessedPartyGroupBatchRun;

public interface ProcessedPartyGroupBatchRunRepository extends CrudRepository<ProcessedPartyGroupBatchRun, Integer>, ProcessedPartyGroupBatchRunCustomRepository {

}
