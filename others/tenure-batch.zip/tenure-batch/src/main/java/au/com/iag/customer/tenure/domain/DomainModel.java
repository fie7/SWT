package au.com.iag.customer.tenure.domain;

public interface DomainModel {

}