package au.com.iag.customer.tenure.dto;

import static java.sql.Timestamp.valueOf;
import static org.apache.commons.beanutils.BeanUtils.copyProperties;
import static org.apache.commons.beanutils.ConvertUtils.register;

import java.lang.reflect.ParameterizedType;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

import au.com.iag.customer.tenure.domain.DomainModel;

//public interface Dto<T extends Dto<T, U>, U extends DomainModel> {
public interface Dto<U extends DomainModel> {

    /*
    @SuppressWarnings("unchecked")
    default Class<? extends Dto<T, U>> getDtoClass() {
        return ((Class<? extends Dto<T, U>>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0]);
    }

    default public T from(U domainModel) {
        try {
            @SuppressWarnings("unchecked")
            T dto = (T) getDtoClass().newInstance();
            copyProperties(domainModel, dto);
            return dto;
        } catch (Exception e) {
            throw new RuntimeException("could not instantiate " + getDtoClass().getName() + "!");
        }
    }
    */

    @SuppressWarnings({ "hiding", "unchecked" })
    default public <LocalDateTime> LocalDateTime timestampToLocalDateTime(Class<LocalDateTime> clazz, Object value) {
        return (LocalDateTime) ((Timestamp) value).toLocalDateTime();
    }

    @SuppressWarnings({ "hiding", "unchecked" })
    default public <Timestamp> Timestamp localDatetimeToTimestamp(Class<Timestamp> clazz, Object value) {
        return (Timestamp) valueOf((LocalDateTime) value);
    }

    @SuppressWarnings("unchecked")
    default public <T extends Dto<U>> T from(Optional<U> domainModel) {  // won't return Optional<T> as that means the caller needs to cast to Optional before casting to Optional<SpecificDtoClass>
        register(this::timestampToLocalDateTime, LocalDateTime.class);
        try {
            if (domainModel.isPresent()) {
                //copyProperties(domainModel.get(), this);
                copyProperties(this, domainModel.get());
                return (T) this;
            } else {
                return null;
            }
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    default Class<? extends U> getDomainModelClass() {
        return ((Class<? extends U>) ((ParameterizedType) getClass().getGenericInterfaces()[0]).getActualTypeArguments()[0]);
    }

    default public U toDomainModel() {
        register(this::localDatetimeToTimestamp, Timestamp.class);
        try {
            U domainModel = getDomainModelClass().newInstance();
            //copyProperties(this, domainModel);
            copyProperties(domainModel, this);
            return domainModel;
        } catch(Exception e) {
            throw new RuntimeException("could not instantiate {}" + getDomainModelClass().getName() + "!", e);
        }
    }
}

