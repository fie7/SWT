package au.com.iag.customer.tenure.dto;

import java.time.Duration;

import au.com.iag.customer.tenure.domain.BatchRun;

//public class TestDto implements Dto<TestDto, BatchRun>{
public class TestDto implements Dto<BatchRun>{
    public static void main(String[] args) {
        Duration d = Duration.parse("PT1h30m");
        System.out.println(d.getSeconds());
        System.out.println(d.getNano());
        
        String s[] = "".split("\\|");
    }
}
