package au.com.iag.customer.tenure.dto;

import java.time.LocalDateTime;

import au.com.iag.customer.tenure.domain.BatchRun;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
//public class BatchRunDto implements Dto<BatchRunDto, BatchRun> {
public class BatchRunDto implements Dto<BatchRun> {
    private int id;
    private LocalDateTime maxTxnTime;
    private LocalDateTime startTime;
    private LocalDateTime finishTime;
    private int txnId;
}
