package au.com.iag.customer.tenure.dto;

import java.time.LocalDateTime;

import au.com.iag.customer.tenure.domain.ProcessedPartyGroupBatchRun;
import au.com.iag.customer.tenure.domain.ProcessingStage;
import au.com.iag.customer.tenure.domain.WarningType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProcessedPartyGroupBatchRunDto implements Dto<ProcessedPartyGroupBatchRun> {
    private Integer id;
    private Integer partyGroupId;
    //private ProcessedPartyGroupDto processedPartyGroupDto;
    private int batchRunId;
    private String mdmId;
    private String request;
    private String response;
    private int httpResponseStatus;
    private WarningType warningType;
    private ProcessingStage processingStage;
    private LocalDateTime processedTime;
}
