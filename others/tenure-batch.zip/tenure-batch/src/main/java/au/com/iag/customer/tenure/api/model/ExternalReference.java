package au.com.iag.customer.tenure.api.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExternalReference {

    private String external_reference_key;

    private String external_reference_value;

    private String information_source;

    private String source_system;
    
}
