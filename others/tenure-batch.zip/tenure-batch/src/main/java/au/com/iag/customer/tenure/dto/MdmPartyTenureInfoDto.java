package au.com.iag.customer.tenure.dto;

import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class MdmPartyTenureInfoDto {
    private int partyGroupId;
    private String mdmId;
    private Integer tenureId;
    private BigDecimal lockedInDiscount;
	private LocalDate tenureCommencementDate;
	private LocalDate tenureExpiryDate;
	private String referenceNo;
    private String overrideReason;
	private Integer txnId;
    private LocalDateTime txnDateTime;
	private String extRef;
	private String extRefKey;
	private String extRefValue;
	private String extRefInfoSource;
	private String extRefSourceSystem;

	private void extractExtRefValues(String[] extRefVals) {
	    // PARTY_ID -> partyId
	    extRefKey = of(extRefVals[2].toLowerCase().split("_")).map(ss -> ss[0] + Character.toUpperCase(ss[1].charAt(0)) + ss[1].substring(1)).get();
	    extRefValue = extRefVals[1];
	    extRefInfoSource = extRefVals[3];
	    extRefSourceSystem = extRefVals[0];
	}

    public MdmPartyTenureInfoDto(int partyGroupId, String mdmId, Integer tenureId, BigDecimal lockedInDiscount, LocalDate tenureCommencementDate,
            LocalDate tenureExpiryDate, String referenceNo, String overrideReason, Integer txnId, LocalDateTime txnDateTime,
            String extRef) {
        super();
        this.partyGroupId = partyGroupId;
        this.mdmId = mdmId;
        this.tenureId = tenureId;
        this.lockedInDiscount = lockedInDiscount;
        this.tenureCommencementDate = tenureCommencementDate;
        this.tenureExpiryDate = tenureExpiryDate;
        this.referenceNo = referenceNo;
        this.overrideReason = overrideReason;
        this.txnId = txnId;
        this.txnDateTime = txnDateTime;
        this.extRef = extRef;
        ofNullable(extRef).map(s -> s.split("\\|")).filter(ss -> ss.length == 4).ifPresent(this::extractExtRefValues);
        if ((ofNullable(extRef).isPresent()) && (! ofNullable(extRefValue).isPresent())) {  // invalid extref!
            log.warn("Invalid EXTREF {} for partyGroupId {} and MDM ID {}", extRef, partyGroupId, mdmId);
        }
    }
}
