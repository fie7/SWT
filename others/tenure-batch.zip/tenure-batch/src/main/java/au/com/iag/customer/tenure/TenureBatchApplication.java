package au.com.iag.customer.tenure;

import static au.com.iag.customer.tenure.domain.WarningType.GROUP_NON_EXISTENT;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;
import static au.com.iag.customer.tenure.domain.WarningType.NULL_CRSD;
import static java.lang.Boolean.TRUE;
import static java.lang.String.valueOf;
import static java.text.MessageFormat.format;
import static java.time.LocalDateTime.now;
import static java.time.ZoneId.systemDefault;
import static java.time.ZoneOffset.UTC;
import static java.time.temporal.ChronoUnit.HOURS;
import static java.time.temporal.ChronoUnit.MINUTES;
import static java.time.temporal.ChronoUnit.SECONDS;
import static java.util.Arrays.asList;
import static java.util.Arrays.sort;
import static java.util.Objects.requireNonNull;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

import java.io.Console;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.client.HttpServerErrorException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import au.com.iag.customer.tenure.api.model.CustomerRelationship;
import au.com.iag.customer.tenure.api.model.ExternalReference;
import au.com.iag.customer.tenure.api.model.TenurePostRequest;
import au.com.iag.customer.tenure.api.model.TenurePostResponse;
import au.com.iag.customer.tenure.api.service.SvxService;
import au.com.iag.customer.tenure.api.service.SvxService.TenureResponseWithStatus;
import au.com.iag.customer.tenure.domain.ProcessingStage;
import au.com.iag.customer.tenure.domain.WarningType;
import au.com.iag.customer.tenure.dto.MdmPartyTenureInfoDto;
import au.com.iag.customer.tenure.dto.ProcessedPartyGroupBatchRunDto;
import au.com.iag.customer.tenure.service.TenureService;
import au.com.iag.customer.tenure.service.TenureService.BatchRuns;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@ComponentScan(basePackages = {"au.com.iag"} )
@Slf4j
public class TenureBatchApplication {
    
    private static ObjectMapper mapper = null;
    private static Map<String, String> envPatterns = null;
    private static Map<String, String> envSvxPatterns = null;
    
    static {
        mapper = new  ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.setSerializationInclusion(NON_NULL);
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        
        envPatterns = new HashMap<>();
        envPatterns.put("VE", ".*ldb0003\\.env-10-100-(\\d+)\\.iagcloud.*");
        envPatterns.put("DEVC", ".*uadsdm01.*");
        envPatterns.put("INTS", ".*uatsdm01.*");
        envPatterns.put("SYSA", ".*uatsdm03.*");
        envPatterns.put("BATA", ".*uatsdm03.*");
        envPatterns.put("BATS", ".*uatscv01.*");
        envPatterns.put("SVP", ".*uatsdm05.*");
        envPatterns.put("TRNG", ".*uaescv01.*");
        envPatterns.put("REPORTING", ".*uapscv01.*");
        envPatterns.put("MIG", ".*ualmig01.auiag.corp:\\d+/(.*):.*");
        envPatterns.put("PERF", ".*ualsdm01.*");
        envPatterns.put("PROD", ".*uapsdm01.*");

        envSvxPatterns = new HashMap<>();
        envSvxPatterns.put("", ".*api\\.((.*)\\.)?svx\\.auiag\\.corp.*");
    }
    
    @Autowired
    private TenureService service;

    @Autowired
    private SvxService svxService;

    // stores the current and last batch runs
    private BatchRuns batchRuns = null;

    private AtomicInteger counter = new AtomicInteger();
    private ProcessingStage processingStage = ProcessingStage.RED_DELTA;
    private int totalRecs = 0;
    private int totalExtRefErrors = 0;
    private AtomicInteger totalSuccess = new AtomicInteger();
    private AtomicInteger totalErrors = new AtomicInteger();
    
    @Value("${tenure.batch.size}")
    private int batchSize;
    @Value("${spring.datasource.url}")
    private String dataSourceUrl;
    @Value("${svx.tenure.end.point}")
    private String svxTenureEndPoint;
    private boolean finalRun = false;
    private boolean persist = true;  // by default persist SVx responses into CRODS db, pass 'false' arg for SVx performance benchmarking only
    private boolean confirm = true;  // by default ask user to confirm before proceeding
    private boolean count = false;  // by default don't enable count mode

    @Data
    @AllArgsConstructor
    public class TenureRequestWithGroupId {
        private int partyGroupId;
        private String mdmId;
        private Integer tenureId;  // if there is an existing tenure info in CRODS db and we pass this in the {@link TenurePostRequest}, this field stores the db ID
        private BigDecimal lockedInDiscount;
        private TenurePostRequest request;
        
        public void addExternalReference(ExternalReference extRef) {
            if (ofNullable(extRef).isPresent()) {
                request.setExternal_references(ofNullable(request.getExternal_references()).orElseGet(ArrayList<ExternalReference>::new));
                request.getExternal_references().add(extRef);
            }
        }

        public void addExternalReferences(List<ExternalReference> extRefs) {
            if (ofNullable(extRefs).isPresent()) {
                request.setExternal_references(ofNullable(request.getExternal_references()).orElseGet(ArrayList<ExternalReference>::new));
                request.getExternal_references().addAll(extRefs);
            }
        }
    }

    public static void main(String[] args) {
		SpringApplication.run(TenureBatchApplication.class, args).close();
	}

	@Bean
	public CommandLineRunner commandLineRunner(ApplicationContext ctx) {
		return args -> {

			System.out.println("Let's inspect the beans provided by Spring Boot:");

			String[] beanNames = ctx.getBeanDefinitionNames();
			sort(beanNames);
			for (String beanName : beanNames) {
				System.out.println(beanName);
			}
		};
	}

	private void insertTenureRecord(MdmPartyTenureInfoDto dto) {
	    System.out.println(dto);
	}
	
    private void test(TenurePostRequest tpr) {
        try {
            System.out.println(mapper.writeValueAsString(tpr));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    private String toJsonString(Object o) {
        try {
            return mapper.writeValueAsString(o);
        } catch (Exception e) {
            return format("Error converting to JSON string: {0}", e.getMessage());
        }
    }

    private String iagPartyId(String mdmId) {
        return "IAG000000" + mdmId;
    }

    private WarningType toWarningType(TenurePostResponse response) {
        /*
        if (response.getCustomer_relationship() == null) {
            return GROUP_NON_EXISTENT;
        } else if (response.getCustomer_relationship().getRelationship_commencement_date() == null) {
            return NULL_CRSD;
        } else {
            return null;
        }
         */
        return of(of(response).map(TenurePostResponse::getCustomer_relationship).map(cr -> ofNullable(cr.getRelationship_commencement_date()).map(d -> 3).orElseGet(() -> 2)).orElseGet(() -> 1)).map(code -> code == 1 ? GROUP_NON_EXISTENT : code == 2 ? NULL_CRSD : null).orElseGet(() -> null);
    }

    private TenureRequestWithGroupId toTenureRequestWithGroupId(MdmPartyTenureInfoDto dto) {
        log.debug("DTO: {}", dto);
        if ((dto.getExtRef() != null) && (dto.getExtRefValue() == null)) {  // invalid extref!
            log.warn("Invalid extRef {}, skipping partyGroupId {} and MDM ID {}...", dto.getExtRef(), dto.getPartyGroupId(), dto.getMdmId());
            totalExtRefErrors++;
            return null;  // skip this record
        }
        try {
    	    return new TenureRequestWithGroupId(
    	        dto.getPartyGroupId()
    	        , dto.getMdmId()
    	        , dto.getTenureId()
    	        , dto.getLockedInDiscount()
    	        , new TenurePostRequest(
    	            iagPartyId(dto.getMdmId())
    	            , ofNullable(dto.getTenureCommencementDate()).isPresent() ? 
    	                new CustomerRelationship(dto.getTenureCommencementDate(), dto.getReferenceNo(), dto.getOverrideReason(), dto.getTenureExpiryDate(), "CRODS", valueOf(dto.getTxnId()), dto.getTxnDateTime().atZone(systemDefault()).withZoneSameInstant(UTC))
    	                : null
    	            , ofNullable(dto.getExtRef()).isPresent() ?
    	                new ArrayList<ExternalReference>(asList(new ExternalReference(dto.getExtRefKey(), dto.getExtRefValue(), dto.getExtRefInfoSource(), dto.getExtRefSourceSystem())))
    	                : null
    	        ));
        } catch(Exception e) {
            log.error("Error converting to Tenure request from DTO: {}", dto);
            return null;
        }
	}

    /*
     * Combines multiple external references for the same party group into one request. 
     */
    private List<TenureRequestWithGroupId> mergeExtRefs(List<TenureRequestWithGroupId> requests, TenureRequestWithGroupId request) {
        requireNonNull(requests);
        requireNonNull(request);
        if (requests.isEmpty()) {
            requests.add(request);
        } else {
            TenureRequestWithGroupId lastRequest = requests.get(requests.size() - 1);
            if (lastRequest.getPartyGroupId() == request.getPartyGroupId()) {  // last element's party group ID is the same as the current processed element
                lastRequest.addExternalReferences(request.getRequest().getExternal_references());  // merge current ext ref with the last one's
            } else {
                requests.add(request);
            }
        }
        return requests;
    }

    public void insertTenureDates(TenureRequestWithGroupId request) {
        //boolean partyGroupProcessed = service.isPartyGroupProcessed(request.getPartyGroupId());
        //counter++;
        int c = -1;

        //log.info("Request: {}", request);
        if (ofNullable(request).isPresent()) {
            log.debug("[{}] Request: {}", processingStage, toJsonString(request.getRequest()));
            log.debug("[{}] calling Svx tenure API for MDM party ID: {}", processingStage, request.getMdmId());
            try {
                TenureResponseWithStatus response = svxService.getTenureDates(request.getRequest());
                //log.info("SVx response[{}]: status -> {} - {} ", counter, response.getStatus(), response.getResponse());
                log.debug("[{}] SVx response: status -> {} - {} ", processingStage, response.getStatus(), toJsonString(response.getResponse()));
                //if ((response.getResponse().getCustomer_relationship().getRelationship_commencement_date() != null) && (request.getTenureId() != null)) {

                if (ofNullable(response).isPresent()) {
                    if (persist) {
                        service.saveTenureDates(batchRuns, request, response.getResponse());
                        log.debug("tenure dates saved");
                        // record this processed party group
                        service.saveProcessedPartyGroup(
                            new ProcessedPartyGroupBatchRunDto(
                                null
                                , request.getPartyGroupId()
                                //, new ProcessedPartyGroupDto(request.getPartyGroupId())
                                , batchRuns.getCurrentRun().getId()
                                , request.getMdmId()
                                , toJsonString(request.getRequest())
                                , toJsonString(response.getResponse())
                                , response.getStatus().value()
                                , toWarningType(response.getResponse())
                                , processingStage 
                                , now()
                            )
                            //, of(delta).filter(DELTA_TYPE.RED::equals).map(d -> true).orElseGet(() -> false)
                            //, partyGroupProcessed
                        );
                    }
                    c = counter.incrementAndGet();  // store to local var as this is a shared resource
                    log.info("[{}] {}. MDM ID {}, party group ID {} marked as processed", processingStage, c, request.getMdmId(), request.getPartyGroupId());
                    totalSuccess.incrementAndGet();
                }
                //}
            } catch(Exception e) {
                // XXX TODO: save error...
                if (persist) {
                    of(e).filter(HttpServerErrorException.class::isInstance).map(HttpServerErrorException.class::cast).ifPresent(ex ->
                        service.saveProcessedPartyGroup(
                            new ProcessedPartyGroupBatchRunDto(
                                null
                                , request.getPartyGroupId()
                                //, new ProcessedPartyGroupDto(request.getPartyGroupId())
                                , batchRuns.getCurrentRun().getId()
                                , request.getMdmId()
                                , toJsonString(request.getRequest())
                                , ex.getResponseBodyAsString()
                                , ex.getRawStatusCode()
                                , null
                                , processingStage
                                , now()
                            )
                            //, partyGroupProcessed
                        )
                    );
                }
                c = counter.incrementAndGet();  // store to local var as this is a shared resource
                log.error("[{}] {}. Error calling SVx tenure API for request {}, proceeding to the next record. Message: {}", processingStage, c, toJsonString(request.getRequest()), e.getMessage());
                totalErrors.incrementAndGet();
            } finally {
                // add to cache if this party group has been processed and wasn't in the database
                //of(partyGroupProcessed).filter(FALSE::equals).map(b -> request.getPartyGroupId()).ifPresent(service.getCachedProcessedPartyGroups()::add);
                if ((c != -1) && (c % 100 == 0)) {
                    log.info("{} records processed", c);
                }
            }
        }
    }
    
    /**
     * Retrieves additional MDM parties who are impacted by recent tenure impacting transactions for processing (red delta).
     */
    public List<MdmPartyTenureInfoDto> getAdditionalMdmPartiesTxnImpacted(boolean finalRun) {
        log.info("retrieving red delta...");
        List<MdmPartyTenureInfoDto> recs = service.getAdditionalMdmPartiesTxnImpacted(finalRun, batchRuns);  // red delta
        log.info("retrieved {} record(s) [{}] to process", recs.size(), processingStage);
        totalRecs += recs.size();
        return recs;
    }

    /**
     * Retrieves additional MDM parties to process (blue delta).
     */
    public List<MdmPartyTenureInfoDto> getAdditionalMdmParties(boolean finalRun, int batchSize) {
        log.info("retrieving blue delta...");
        List<MdmPartyTenureInfoDto> recs = service.getAdditionalMdmParties(finalRun, batchRuns, batchSize);  // blue delta
        log.info("retrieved {} record(s) [{}] to process", recs.size(), processingStage);
        //totalRecs += recs.size();
        return recs;
    }
    
    /**
     * Retrieves MDM parties whose processing had errors in their last runs.
     */
    public List<MdmPartyTenureInfoDto> getPreviousErrorsMdmParties(boolean finalRun) {
        log.info("retrying parties with errors in their last runs...");
        List<MdmPartyTenureInfoDto> recs = service.getPreviousErrorsMdmParties(finalRun, batchRuns);
        log.info("retrieved {} record(s) [{}] to process", recs.size(), processingStage);
        //totalRecs += recs.size();
        return recs;
    }

    /**
     * Counts additional MDM parties who are impacted by recent tenure impacting transactions for processing (red delta).
     */
    public int countAdditionalMdmPartiesTxnImpacted(boolean finalRun) {
        log.info("retrieving red delta...");
        int recCount = service.countAdditionalMdmPartiesTxnImpacted(finalRun, batchRuns);  // red delta
        log.info("retrieved {} record(s) [{}] to process", recCount, processingStage);
        totalRecs += recCount;
        return recCount;
    }

    /**
     * Counts additional MDM parties to process (blue delta).
     */
    public int countAdditionalMdmParties(boolean finalRun, int batchSize) {
        log.info("retrieving blue delta...");
        int recCount = service.countAdditionalMdmParties(finalRun, batchRuns, batchSize);  // blue delta
        log.info("retrieved {} record(s) [{}] to process", recCount, processingStage);
        totalRecs += recCount;
        return recCount;
    }
    
    /**
     * Counts MDM parties whose processing had errors in their last runs.
     */
    public int countPreviousErrorsMdmParties(boolean finalRun) {
        log.info("retrying parties with errors in their last runs...");
        int recCount = service.countPreviousErrorsMdmParties(finalRun, batchRuns);
        log.info("retrieved {} record(s) [{}] to process", recCount, processingStage);
        totalRecs += recCount;
        return recCount;
    }

    private void printStats(LocalDateTime startTime, LocalDateTime finishTime) {
        //log.info("============ Total # records: {}, # skipped: {}, # success: {}, # errors: {}, variance: {} ============", totalRecs, totalExtRefErrors, totalSuccess.get(), totalErrors.get(), (totalRecs - (totalExtRefErrors + totalSuccess.get() + totalErrors.get())));
        log.info("============ Total # records (party groups): {}, # skipped: {}, # success: {}, # errors: {}, variance: {} ============", totalRecs, totalExtRefErrors, totalSuccess.get(), totalErrors.get(), (totalRecs - (totalSuccess.get() + totalErrors.get())));
        log.info("============ Batch started {}, finished {}. Duration: {} hour(s) {} min(s) {} sec(s)! ============"
            , startTime
            , finishTime
            , HOURS.between(startTime, finishTime)
            , (MINUTES.between(startTime, finishTime) % 60)
            , (SECONDS.between(startTime, finishTime)) % 60);
    }
    
    private void printPreview(int redDelta, int blueDelta, int retryErrors) {
        log.info("################################");
        log.info("RED DELTA: {}", redDelta);
        log.info("BLUE DELTA: {}", blueDelta);
        log.info("RETRY PREVIOUS ERRORS: {}", retryErrors);
        log.info("TOTAL RECS => {}", redDelta + blueDelta + retryErrors);
        log.info("################################");
    }
    
    private boolean checkMandatoryArgs(String...args) {
        requireNonNull(args);
        boolean finalRunArg = asList(args).stream().map(String::toLowerCase).filter(arg -> arg.startsWith("finalrun=")).findFirst().map(arg -> true).orElseGet(() -> false);
        if (! finalRunArg) {
            log.error("finalRun arg is required!");
        }
        return finalRunArg;
    }
    
    private Optional<String> parseArgs(String argName, String...args) {
        requireNonNull(argName);
        requireNonNull(args);
        return asList(args).stream().map(String::toLowerCase).filter(arg -> arg.startsWith(argName.toLowerCase() + "=")).findFirst().filter(arg -> arg.split("=").length == 2).map(arg -> arg.split("=")[1]);
    }

    public static void waitForEnter(String message, Object... args) {
        Console c = System.console();
        if (c != null) {
          // printf-like arguments
          if (message != null)
            c.format(message, args);
          c.format("\nPress ENTER to proceed, <CTRL-C> to cancel.\n");
          c.readLine();
        }
    }
    
    private String getEnv() {
        String env = null;
        Iterator<Entry<String, String>> it = envPatterns.entrySet().iterator();
        while(it.hasNext()) {
            Entry<String, String> entry = it.next();
            Matcher m = Pattern.compile(entry.getValue()).matcher(dataSourceUrl.toLowerCase());
            if (m.find()) {
                env = entry.getKey();
                if ("VE".equals(env)) {
                    env += m.group(1);
                } else if ("MIG".equals(env)) {
                    switch(m.group(1)) {
                        case "l01scvd2":
                            env += "2";
                            break;
                        case "l01scvd3":
                            env += "3";
                            break;
                        default:
                            throw new RuntimeException("Unknown environment!");
                    }
                }
                return env;
            }
        }
        log.error("Unknown db env {}!", dataSourceUrl);
        throw new RuntimeException("Unknown environment!");
    }

    private String getSvxEnv() {
        String env = null;
        Iterator<Entry<String, String>> it = envSvxPatterns.entrySet().iterator();
        while(it.hasNext()) {
            Entry<String, String> entry = it.next();
            Matcher m = Pattern.compile(entry.getValue()).matcher(svxTenureEndPoint.toLowerCase());
            if (m.find()) {
                env = entry.getKey();
                if ("".equals(env)) {
                    env += ofNullable(m.group(2)).orElseGet(() -> "prod").toUpperCase();
                }
                return env;
            }
        }
        log.error("Unknown SVx env {}!", svxTenureEndPoint);
        throw new RuntimeException("Unknown SVx environment!");
    }

    @Bean
    public CommandLineRunner execute(ApplicationContext ctx) {
        return args -> {
            /*
            boolean finalRun = false;
            if ((args.length < 1) || (! args[0].toLowerCase().startsWith("finalrun"))) {
                log.error("finalRun arg is required!");
                throw new RuntimeException("finalRun arg is required!");
            } else {
                String[] ss = args[0].split("=");
                finalRun = (ss.length == 2) && ss[0].equalsIgnoreCase("finalrun") && Boolean.valueOf(ss[1]);
            }
            */
            if (checkMandatoryArgs(args)) {
                finalRun = parseArgs("finalRun", args).map(Boolean::valueOf).orElseGet(() -> finalRun);  // take value from passed arg, or else use default
                batchSize = parseArgs("batchSize", args).map(Integer::valueOf).orElseGet(() -> batchSize);  // take value from passed arg, or else use default
                confirm = parseArgs("confirm", args).map(Boolean::valueOf).orElseGet(() -> confirm);  // take value from passed arg, or else use default
                count = parseArgs("count", args).map(Boolean::valueOf).orElseGet(() -> count);  // take value from passed arg, or else use default
                if (count) {  // enable dry run if in count mode
                    persist = false;
                } else {
                    persist = parseArgs("persist", args).map(Boolean::valueOf).orElseGet(() -> persist);  // take value from passed arg, or else use default
                }
                log.info("****** ENVIRONMENTS: CRODS [{}] ------> SVx [{}] ******", getEnv(), getSvxEnv());
                log.info("****** using settings batchSize: {}, finalRun: {}, persist: {}, confirm: {}, count: {}! ******", batchSize, finalRun, persist, confirm, count);
                if (confirm) {
                    waitForEnter("============= CONFIRM IF CORRECT!!!!!! =============");
                }
            } else {
                return;
            }

            // initialises a batch run (i.e. determine batch run no, etc)
            log.info("initialising batch run...");
            //batchRuns = service.nextAndLastBatchRuns();
            batchRuns = of(persist).filter(TRUE::equals).map(b -> service.nextAndLastBatchRuns()).orElseGet(service::mockNextAndLastBatchRuns);
            log.info("batch run #{}", batchRuns.getCurrentRun().getId());
            //service.getAdditionalMdmParties().stream().forEach(this::insertTenureRecord);
            //service.getAdditionalMdmParties().stream().map(this::toTenurePostRequest).forEach(this::test);

            if (count) {
                // process red delta...
                processingStage = ProcessingStage.RED_DELTA;
                int redDelta = countAdditionalMdmPartiesTxnImpacted(finalRun);
    
                // process blue delta...
                processingStage = ProcessingStage.BLUE_DELTA;
                int blueDelta = countAdditionalMdmParties(finalRun, batchSize);
    
                // retry previous errors...
                processingStage = ProcessingStage.RETRY_PREVIOUS_ERRORS;
                int retryErrors = countPreviousErrorsMdmParties(finalRun);
                
                totalSuccess.set(redDelta + blueDelta + retryErrors);
                printPreview(redDelta, blueDelta, retryErrors);
            } else {
                // process red delta...
                //processingStage = ProcessingStage.RED_DELTA;
                //getAdditionalMdmPartiesTxnImpacted(finalRun).parallelStream().map(this::toTenureRequestWithGroupId).forEach(this::insertTenureDates);  // dtos -> requests -> responses
    
                //counter = 0;  // reset counter
                // process blue delta...
                processingStage = ProcessingStage.BLUE_DELTA;
                //getAdditionalMdmParties(finalRun, batchSize).parallelStream().map(this::toTenureRequestWithGroupId).forEach(this::insertTenureDates);  // dtos -> requests -> responses
                List<TenureRequestWithGroupId> requests = getAdditionalMdmParties(finalRun, batchSize).stream().map(this::toTenureRequestWithGroupId).filter(Objects::nonNull).collect(ArrayList::new, this::mergeExtRefs, ArrayList::addAll);
                totalRecs += requests.size();
                requests.parallelStream().forEach(this::insertTenureDates);  // dtos -> requests -> responses
                /*
                ForkJoinPool pool = new ForkJoinPool(10); 
                pool.submit(() -> getAdditionalMdmParties(finalRun, batchSize).parallelStream().map(this::toTenureRequestWithGroupId).forEach(this::insertTenureDates)).get();
                pool.shutdown();
                */
    
                //counter = 0;  // reset counter
                // retry previous errors...
                processingStage = ProcessingStage.RETRY_PREVIOUS_ERRORS;
                //getPreviousErrorsMdmParties(finalRun).parallelStream().map(this::toTenureRequestWithGroupId).forEach(this::insertTenureDates);  // dtos -> requests -> responses
                requests = getPreviousErrorsMdmParties(finalRun).stream().map(this::toTenureRequestWithGroupId).filter(Objects::nonNull).collect(ArrayList::new, this::mergeExtRefs, ArrayList::addAll);
                totalRecs += requests.size();
                requests.parallelStream().forEach(this::insertTenureDates);  // dtos -> requests -> responses
            }

            //LocalDateTime finishTime = service.recordFinishTime(batchRuns.getCurrentRun());
            LocalDateTime finishTime = of(persist).filter(TRUE::equals).map(b -> service.recordFinishTime(batchRuns.getCurrentRun())).orElseGet(LocalDateTime::now);
            log.info("done!");
            printStats(batchRuns.getCurrentRun().getStartTime(), finishTime);
            //log.info("max txnID: {}", service.getMaxTxnIdByAge());
        };
    }
}
