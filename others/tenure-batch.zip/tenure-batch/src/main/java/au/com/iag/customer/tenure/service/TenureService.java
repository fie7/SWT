package au.com.iag.customer.tenure.service;

import static java.sql.Timestamp.valueOf;
import static java.time.Duration.parse;
import static java.time.LocalDateTime.now;
import static java.util.Objects.nonNull;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toSet;
import static java.util.stream.StreamSupport.stream;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import au.com.iag.customer.tenure.TenureBatchApplication.TenureRequestWithGroupId;
import au.com.iag.customer.tenure.api.model.CustomerRelationship;
import au.com.iag.customer.tenure.api.model.TenurePostResponse;
import au.com.iag.customer.tenure.dao.TenureDao;
import au.com.iag.customer.tenure.domain.BatchRun;
import au.com.iag.customer.tenure.domain.ProcessedPartyGroup;
import au.com.iag.customer.tenure.domain.ProcessedPartyGroupBatchRun;
import au.com.iag.customer.tenure.dto.BatchRunDto;
import au.com.iag.customer.tenure.dto.MdmPartyTenureInfoDto;
import au.com.iag.customer.tenure.dto.ProcessedPartyGroupBatchRunDto;
import au.com.iag.customer.tenure.repository.BatchRunRepository;
import au.com.iag.customer.tenure.repository.ProcessedPartyGroupBatchRunRepository;
import au.com.iag.customer.tenure.repository.ProcessedPartyGroupRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TenureService {
    private Set<Integer> cachedProcessedPartyGroups = null;
    private boolean loaded = false;

    @Data
    @AllArgsConstructor
    public class BatchRuns {
        private BatchRunDto currentRun;
        private BatchRunDto previousRun;
    }

    //@Value("${tenure.batch.size}")
    //private int batchSize;

    @Value("${tenure.txn.age.exclude}")
    private String txnExclAge;
    
    private Duration exclAgeDuration;

    private final TenureDao dao;
    private final BatchRunRepository batchRunRepository;
    //private final ProcessedPartyGroupRepository processedPartyGroupRepository;
    private final ProcessedPartyGroupBatchRunRepository processedPartyGroupBatchRunRepository;

    @Autowired
    public TenureService(TenureDao dao, BatchRunRepository batchRunRepository, /*ProcessedPartyGroupRepository processedPartyGroupRepository,*/ ProcessedPartyGroupBatchRunRepository processedPartyGroupBatchRunRepository) {
        this.dao = dao;
        this.batchRunRepository = batchRunRepository;
        //this.processedPartyGroupRepository = processedPartyGroupRepository;
        this.processedPartyGroupBatchRunRepository = processedPartyGroupBatchRunRepository;
    }

    @PostConstruct
    private void init() {
        this.exclAgeDuration = parse("PT" + txnExclAge);
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<MdmPartyTenureInfoDto> getAdditionalMdmParties(boolean finalRun, BatchRuns batchRuns, int batchSize) {
        return dao.getAdditionalMdmParties(batchSize, finalRun, batchRuns).collect(Collectors.toList());
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<MdmPartyTenureInfoDto> getAdditionalMdmPartiesTxnImpacted(boolean finalRun, BatchRuns batchRuns) {
        return dao.getAdditionalMdmPartiesTxnImpacted(finalRun, batchRuns).collect(Collectors.toList());
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<MdmPartyTenureInfoDto> getPreviousErrorsMdmParties(boolean finalRun, BatchRuns batchRuns) {
        return dao.getPreviousErrorsMdmParties(finalRun, batchRuns).collect(Collectors.toList());
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public int countAdditionalMdmParties(boolean finalRun, BatchRuns batchRuns, int batchSize) {
        return dao.countAdditionalMdmParties(batchSize, finalRun, batchRuns);
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public int countAdditionalMdmPartiesTxnImpacted(boolean finalRun, BatchRuns batchRuns) {
        return dao.countAdditionalMdmPartiesTxnImpacted(finalRun, batchRuns);
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public int countPreviousErrorsMdmParties(boolean finalRun, BatchRuns batchRuns) {
        return dao.countPreviousErrorsMdmParties(finalRun, batchRuns);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public BatchRunDto nextBatchRun() {
        int batchTxnId = dao.nextTxnId();  // create a new txn ID for this batch run
        LocalDateTime startTime = now();
        LocalDateTime maxTxnTime = startTime.minus(exclAgeDuration);
        //if .from() below returns Optional<> needs to upcast to Optional first before cast again to Optional<SpecificDtoClass>, i.e. to cast List<Object> to List<String> needs to upcast to Object or List first or else compiler will complain.
        //return ((Optional<BatchRunDto>) (Optional) new BatchRunDto().from(of(batchRunRepository.save(new BatchRun(valueOf(maxTxnTime), valueOf(startTime), batchTxnId))))).get();
        return new BatchRunDto().from(of(batchRunRepository.save(new BatchRun(valueOf(maxTxnTime), valueOf(startTime), batchTxnId))));
    }

    /**
     * Returns a new {@link BatchRunDto} and the lastest {BatchRunDto} prior to this.
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public BatchRuns nextAndLastBatchRuns() {
        /*
        BatchRunDto thisRun = nextBatchRun();
        return new BatchRuns(thisRun
            , new BatchRunDto().from(batchRunRepository.findById(thisRun.getId() - 1)));  // retrieve previous run (findById() returns Optional.empty if it's initial run)
        */
        BatchRunDto previousRun = new BatchRunDto().from(batchRunRepository.findTopByOrderByIdDesc());  // retrieve previous run (findById() returns Optional.empty if it's initial run) 
        BatchRunDto thisRun = nextBatchRun();
        return new BatchRuns(thisRun, previousRun);
    }

    public BatchRuns mockNextAndLastBatchRuns() {
        BatchRunDto previousRun = new BatchRunDto().from(batchRunRepository.findTopByOrderByIdDesc());  // retrieve previous run (findById() returns Optional.empty if it's initial run) 

        int batchTxnId = 0;  // create a new txn ID for this batch run
        LocalDateTime startTime = now();
        LocalDateTime maxTxnTime = startTime.minus(exclAgeDuration);
        //if .from() below returns Optional<> needs to upcast to Optional first before cast again to Optional<SpecificDtoClass>, i.e. to cast List<Object> to List<String> needs to upcast to Object or List first or else compiler will complain.
        //return ((Optional<BatchRunDto>) (Optional) new BatchRunDto().from(of(batchRunRepository.save(new BatchRun(valueOf(maxTxnTime), valueOf(startTime), batchTxnId))))).get();
        BatchRun br = new BatchRun(valueOf(maxTxnTime), valueOf(startTime), batchTxnId);
        br.setId(0);
        BatchRunDto thisRun = new BatchRunDto().from(of(br));

        return new BatchRuns(thisRun, previousRun);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public void saveTenureDates(BatchRuns batchRuns, TenureRequestWithGroupId request, TenurePostResponse response) {
        nonNull(batchRuns);
        nonNull(request);
        nonNull(response);
//        if (ofNullable(response.getCustomer_relationship().getRelationship_commencement_date()).isPresent()
//            && ofNullable(response.getCustomer_relationship().getRelationship_expirydate()).isPresent()) {
            if (ofNullable(response.getCustomer_relationship()).map(CustomerRelationship::getRelationship_commencement_date).isPresent()
                && ofNullable(response.getCustomer_relationship().getRelationship_expirydate()).isPresent()) {

            if (ofNullable(request.getTenureId()).isPresent()) {  // update
                dao.amendLoyaltyRelationship(batchRuns, request, response);
            } else {  // insert
                dao.createLoyaltyRelationship(batchRuns, request, response);
            }
        }
    }

    /*
    @Transactional(propagation = Propagation.REQUIRED)
    public void saveProcessedPartyGroup(ProcessedPartyGroupBatchRunDto dto, boolean skipParentEntity) {
        ProcessedPartyGroupBatchRun domainModel = dto.toDomainModel();
        if (skipParentEntity) {
            processedPartyGroupBatchRunRepository.insertWithQuery(domainModel);
        } else {
            // XXX TODO: enhance to do deep copy!
            domainModel.setProcessedPartyGroup(new ProcessedPartyGroup(domainModel.getPartyGroupId()));
            processedPartyGroupBatchRunRepository.save(domainModel);
            // update cache
            cachedProcessedPartyGroups.add(domainModel.getPartyGroupId());
            log.debug("added party group {} to cache", domainModel.getPartyGroupId());
        }
    }
    */

    @Transactional(propagation = Propagation.REQUIRED)
    public void saveProcessedPartyGroup(ProcessedPartyGroupBatchRunDto dto) {
        //processedPartyGroupBatchRunRepository.save(dto.toDomainModel());
        processedPartyGroupBatchRunRepository.insertWithQuery(dto.toDomainModel());
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public LocalDateTime recordFinishTime(BatchRunDto currentRunDto) {
        LocalDateTime finishTime = now();
        
        batchRunRepository.findById(currentRunDto.getId()).get().setFinishTime(valueOf(finishTime));
        return finishTime;
    }

    /*
    public Set<Integer> getCachedProcessedPartyGroups() {
        if (! loaded) {  // NOT thread-safe!
            log.info("loading processed party groups into cache...");
            cachedProcessedPartyGroups = stream(processedPartyGroupRepository.findAll().spliterator(), false).map(ProcessedPartyGroup::getPartyGroupId).collect(toSet());
            log.info("done, {} party groups cached!", cachedProcessedPartyGroups.size());
            loaded = true;
        }
        return cachedProcessedPartyGroups;
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public boolean isPartyGroupProcessed(int partyGroupId, boolean useCache) {
        if (useCache) {
            return getCachedProcessedPartyGroups().contains(partyGroupId);
        } else {
            return processedPartyGroupRepository.findById(partyGroupId).isPresent();
        }
    }

    // Uses cache by default 
    public boolean isPartyGroupProcessed(int partyGroupId) {
        return isPartyGroupProcessed(partyGroupId, true);
    }
    */

    @Transactional(propagation = Propagation.REQUIRED)
    public int getMaxTxnIdByAge() {
        return dao.getMaxTxnIdByAge(exclAgeDuration);
    }
}