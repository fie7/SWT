package au.com.iag.customer.tenure.repository;

import au.com.iag.customer.tenure.domain.ProcessedPartyGroupBatchRun;

public interface ProcessedPartyGroupBatchRunCustomRepository {
    
    public void insertWithQuery(ProcessedPartyGroupBatchRun processedPartyGroupBatchRun);
    
}
