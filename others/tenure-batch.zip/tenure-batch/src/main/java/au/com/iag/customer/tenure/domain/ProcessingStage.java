package au.com.iag.customer.tenure.domain;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum ProcessingStage {
    RED_DELTA(1), BLUE_DELTA(2), RETRY_PREVIOUS_ERRORS(3);

    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
 
}
