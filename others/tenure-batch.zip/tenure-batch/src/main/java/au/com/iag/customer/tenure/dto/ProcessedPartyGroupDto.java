package au.com.iag.customer.tenure.dto;

import au.com.iag.customer.tenure.domain.ProcessedPartyGroup;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProcessedPartyGroupDto implements Dto<ProcessedPartyGroup> {
    private int partyGroupId;
}
