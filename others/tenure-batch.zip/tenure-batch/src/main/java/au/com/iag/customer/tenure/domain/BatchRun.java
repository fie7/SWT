package au.com.iag.customer.tenure.domain;

import static javax.persistence.GenerationType.IDENTITY;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name="batch_run", schema="temp")
@Data
//@NoArgsConstructor(access = AccessLevel.PRIVATE)
@RequiredArgsConstructor
@NoArgsConstructor
public class BatchRun implements DomainModel {

    @Id
    @GeneratedValue(strategy=IDENTITY)  // if we comment this out, will ask to supply explicit value
    protected Integer id;

    @Column(name = "max_txn_time")
    @NonNull
    private Timestamp maxTxnTime;

    @Column(name = "start_time")
    @NonNull
    private Timestamp startTime;

    @Column(name = "finish_time")
    private Timestamp finishTime;

    @Column(name = "TXN_ID")
    @NonNull
    private Integer txnId;

}
