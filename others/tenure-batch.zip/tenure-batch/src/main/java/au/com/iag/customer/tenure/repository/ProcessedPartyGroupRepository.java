package au.com.iag.customer.tenure.repository;

import org.springframework.data.repository.CrudRepository;

import au.com.iag.customer.tenure.domain.ProcessedPartyGroup;

public interface ProcessedPartyGroupRepository extends CrudRepository<ProcessedPartyGroup, Integer> {
    
}
