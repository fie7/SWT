package au.com.iag.customer.tenure.dao;

import static au.com.iag.customer.tenure.util.DateUtil.localDateTimeToDate;
import static au.com.iag.customer.tenure.util.DateUtil.localDateToDate;
import static java.sql.Timestamp.valueOf;
import static java.text.MessageFormat.format;
import static java.time.LocalDateTime.now;
import static java.time.Month.DECEMBER;
import static java.util.Arrays.stream;
import static java.util.Collections.singletonMap;
import static java.util.Objects.nonNull;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import au.com.iag.customer.tenure.TenureBatchApplication.TenureRequestWithGroupId;
import au.com.iag.customer.tenure.api.model.TenurePostResponse;
import au.com.iag.customer.tenure.dto.BatchRunDto;
import au.com.iag.customer.tenure.dto.MdmPartyTenureInfoDto;
import au.com.iag.customer.tenure.mapper.MdmPartyTenureInfoRowMapper;
import au.com.iag.customer.tenure.service.TenureService.BatchRuns;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class TenureDao {

    private static final String USER_PROFILE = "IAGSM";
    private static final String USER_ID = "MDM-869";
    private final NamedParameterJdbcTemplate template;
    private final SimpleJdbcCall newTxnCall, newLoyaltyCall, amendLoyaltyCall;
    private final TenureQueries queries;
    private final RowMapper<MdmPartyTenureInfoDto> rowMapper;
    private final ResultSetExtractor<Integer> intRse = rs -> { rs.next(); return rs.getInt(1); };

    private SqlParameterSource newTxnParams() {
        return new MapSqlParameterSource("user_profile_in", USER_PROFILE)
            .addValue("userid_in", USER_ID)
            .addValue("tran_type_cde_in", "CREATE")
            .addValue("tran_subtype_cde_in", "CUSTOMER")
            .addValue("user_channel_cde_in", "SCV")
            .addValue("user_location_cde_in", "SCV")
            ;
    }
    
    private SqlParameterSource createLoyaltyParams(BatchRuns batchRuns, TenureRequestWithGroupId request, TenurePostResponse response) {
        return new MapSqlParameterSource("user_profile_in", USER_PROFILE)
            .addValue("userid_in", USER_ID)
            .addValue("transaction_id_in", batchRuns.getCurrentRun().getTxnId())
            .addValue("party_grp_id_in", request.getPartyGroupId())
            .addValue("rel_commence_date_in", localDateToDate(response.getCustomer_relationship().getRelationship_commencement_date()))
            .addValue("reference_no_in", response.getCustomer_relationship().getReference_number())
            .addValue("override_reason_in", response.getCustomer_relationship().getRelationship_override_reason())
            .addValue("rel_expiry_date_in", localDateToDate(response.getCustomer_relationship().getRelationship_expirydate()))
            .addValue("locked_in_discount_in", null)
            .addValue("function_mode_in", "CREATE")
            .addValue("start_date_in", localDateTimeToDate(batchRuns.getCurrentRun().getStartTime()))
            .addValue("end_date_in", localDateToDate(LocalDate.of(9999, DECEMBER, 31)))
            .addValue("loy_relationship_id_in", null)
            ;
    }

    /*
    private SqlParameterSource amendLoyaltyParams(BatchRuns batchRuns, TenureRequestWithGroupId request, TenurePostResponse response) {
        return new MapSqlParameterSource("user_profile_in", USER_PROFILE)
            .addValue("userid_in", USER_ID)
            .addValue("transaction_id_in", batchRuns.getCurrentRun().getTxnId())
            .addValue("table_name_in", "loy_relationship")
            .addValue("row_id_key_in", "loy_relationship_id")
            .addValue("row_id_val_in", request.getTenureId())
            .addValue("column_name1_in", "rel_commence_date")
            .addValue("value1_in", response.getCustomer_relationship().getRelationship_commencement_date().toString())
            .addValue("column_name2_in", "rel_expiry_date")
            .addValue("value2_in", response.getCustomer_relationship().getRelationship_expirydate().toString())
            ;
    }
    */

    private SqlParameterSource amendLoyaltyParams(BatchRuns batchRuns, TenureRequestWithGroupId request, TenurePostResponse response) {
        return new MapSqlParameterSource("user_profile_in", USER_PROFILE)
                .addValue("userid_in", USER_ID)
                .addValue("transaction_id_in", batchRuns.getCurrentRun().getTxnId())
                .addValue("party_grp_id_in", request.getPartyGroupId())
                .addValue("rel_commence_date_in", localDateToDate(response.getCustomer_relationship().getRelationship_commencement_date()))
                .addValue("reference_no_in", response.getCustomer_relationship().getReference_number())
                .addValue("override_reason_in", response.getCustomer_relationship().getRelationship_override_reason())
                .addValue("rel_expiry_date_in", localDateToDate(response.getCustomer_relationship().getRelationship_expirydate()))
                //.addValue("locked_in_discount_in", request.getLockedInDiscount())
                .addValue("locked_in_discount_in", null)
                .addValue("function_mode_in", "AMEND")
                .addValue("start_date_in", localDateTimeToDate(batchRuns.getCurrentRun().getStartTime()))
                .addValue("end_date_in", localDateToDate(LocalDate.of(9999, DECEMBER, 31)))
                .addValue("loy_relationship_id_in", request.getTenureId())
                ;
    }
    
    private void checkErrors(Map<String, Object> out, SimpleJdbcCall caller) {
        /*
        of(out.get("app_error_out")).map(Integer.class::cast).filter(i -> i.equals(0)).orElseThrow(() -> new RuntimeException(""));
        if (! ((Integer) out.get("app_error_out")).equals(0)) {
            throw new RuntimeException("");
        }
        */
        // case sensitive!
        stream(new Object[] { ofNullable(out.get("APP_ERROR_OUT")).orElseGet(() -> 0), ofNullable(out.get("SQLCODE_OUT")).orElseGet(() -> 0) })
            .map(Integer.class::cast)
            .filter(i -> ! i.equals(0))
            .findFirst()
            .ifPresent(t -> {
                log.error("appError: {}, appErrorText: {}, sqlCode: {}, sqlState: {}", out.get("APP_ERROR_OUT"), out.get("APP_ERROR_TEXT_OUT"), out.get("SQLCODE_OUT"), out.get("SQLSTATE_OUT"));
                throw new RuntimeException(format("Error calling stored proc {0}.{1}!", caller.getSchemaName(), caller.getProcedureName()));
            });
    }

    @Autowired
    public TenureDao(NamedParameterJdbcTemplate template, TenureQueries queries) {
        this.template = template;
        this.newTxnCall = new SimpleJdbcCall(template.getJdbcTemplate()).withSchemaName("crods").withProcedureName("create_transaction");
        this.newLoyaltyCall = new SimpleJdbcCall(template.getJdbcTemplate()).withSchemaName("crods").withProcedureName("create_loy_relationship");
        this.amendLoyaltyCall = new SimpleJdbcCall(template.getJdbcTemplate()).withSchemaName("crods").withProcedureName("amend_loy_relationship");
        //this.amendLoyaltyCall = new SimpleJdbcCall(template.getJdbcTemplate()).withSchemaName("crods").withProcedureName("amend_any");
        //this.amendLoyaltyCall = new SimpleJdbcCall(template.getJdbcTemplate()).withSchemaName("crods").withProcedureName("amend_any_test");
        this.rowMapper = new MdmPartyTenureInfoRowMapper();
        this.queries = queries;
    }

    public int nextTxnId() {
        Map<String, Object> out = newTxnCall.execute(newTxnParams());
        checkErrors(out, newTxnCall);
        return of(out.get("TRANSACTION_ID_OUT")).map(Integer.class::cast).get();
    }

    public int createLoyaltyRelationship(BatchRuns batchRuns, TenureRequestWithGroupId request, TenurePostResponse response) {
        nonNull(batchRuns);
        nonNull(request);
        nonNull(response);
        Map<String, Object> out = newLoyaltyCall.execute(createLoyaltyParams(batchRuns, request, response));
        checkErrors(out, newLoyaltyCall);
        return of(out.get("LOY_RELATIONSHIP_ID_OUT")).map(Integer.class::cast).get();
    }

    public void amendLoyaltyRelationship(BatchRuns batchRuns, TenureRequestWithGroupId request, TenurePostResponse response) {
        nonNull(batchRuns);
        nonNull(request);
        nonNull(response);
        Map<String, Object> out = amendLoyaltyCall.execute(amendLoyaltyParams(batchRuns, request, response));
        checkErrors(out, amendLoyaltyCall);
    }

    // XXX TODO: check what happens if first run is also a final run??????
    private Map<String, Object> getAdditionalMdmPartiesParams(int batchSize, boolean finalRun, BatchRuns batchRuns) {
        Map<String, Object> paramMap = new HashMap<>();
        Timestamp startTime = valueOf(batchRuns.getCurrentRun().getMaxTxnTime());
        paramMap.put("startTime", startTime);
        paramMap.put("endTime", finalRun ? startTime : valueOf("9999-12-31 23:59:59.999999999"));  // setting end time equals start time in the final run ensures the MINUS set is empty, so it will pick up remaining...
        paramMap.put("finalRun", finalRun ? 1 : 0);
        paramMap.put("batchSize", batchSize);
        return paramMap;
    }

    private Map<String, Object> getAdditionalMdmPartiesTxnImpactedParams(boolean finalRun, BatchRuns batchRuns) {
        Map<String, Object> paramMap = new HashMap<>();
        /*
        boolean initialRun = batchRuns.getPreviousRun() == null;
        Timestamp startTime = initialRun ? null : batchRuns.getPreviousRun().getMaxTxnTime();
        */
        
        Timestamp startTime = ofNullable(batchRuns.getPreviousRun()).map(BatchRunDto::getMaxTxnTime).map(Timestamp::valueOf).orElseGet(() -> null); 
        //Timestamp startTime = valueOf(batchRuns.getPreviousRun().getMaxTxnTime());
        paramMap.put("startTime", startTime);
        paramMap.put("endTime", finalRun ? valueOf(batchRuns.getCurrentRun().getStartTime()) : valueOf(batchRuns.getCurrentRun().getMaxTxnTime()));
        /*
        paramMap.put("initialRun", batchRuns.getPreviousRun() == null ? new Integer(1) : new Integer(0));
        */
        paramMap.put("initialRun", ofNullable(batchRuns.getPreviousRun()).map(dto -> new Integer(0)).orElseGet(() -> new Integer(1)));
        return paramMap;
    }

    private Map<String, Object> getPreviousErrorsMdmPartiesParams(boolean finalRun, BatchRuns batchRuns) {
        Map<String, Object> paramMap = new HashMap<>();
        Timestamp startTime = valueOf(batchRuns.getCurrentRun().getMaxTxnTime());
        paramMap.put("currentBatchRunId", batchRuns.getCurrentRun().getId());
        paramMap.put("startTime", startTime);
        paramMap.put("endTime", finalRun ? startTime : valueOf("9999-12-31 23:59:59.999999999"));  // setting end time equals start time in the final run ensures the MINUS set is empty, so it will pick up remaining...
        paramMap.put("finalRun", finalRun ? 1 : 0);
        return paramMap;
    }

    // blue delta
    public Stream<MdmPartyTenureInfoDto> getAdditionalMdmParties(int batchSize, boolean finalRun, BatchRuns batchRuns) {
        String sql = queries.getAdditionalMdmParties();
        return template.query(sql, getAdditionalMdmPartiesParams(batchSize, finalRun, batchRuns), rowMapper).stream();
    }

    // red delta
    public Stream<MdmPartyTenureInfoDto> getAdditionalMdmPartiesTxnImpacted(boolean finalRun, BatchRuns batchRuns) {
        String sql = queries.getAdditionalMdmPartiesTxnImpacted();
        return template.query(sql, getAdditionalMdmPartiesTxnImpactedParams(finalRun, batchRuns), rowMapper).stream();
    }

    // previous errors to retry
    public Stream<MdmPartyTenureInfoDto> getPreviousErrorsMdmParties(boolean finalRun, BatchRuns batchRuns) {
        String sql = queries.getPreviousErrorsMdmParties();
        return template.query(sql, getPreviousErrorsMdmPartiesParams(finalRun, batchRuns), rowMapper).stream();
    }

    // count blue delta
    public int countAdditionalMdmParties(int batchSize, boolean finalRun, BatchRuns batchRuns) {
        String sql = "select count(*) from (" + queries.getAdditionalMdmParties() + ")";
        return template.query(sql, getAdditionalMdmPartiesParams(batchSize, finalRun, batchRuns), intRse);
    }

    // count red delta
    public int countAdditionalMdmPartiesTxnImpacted(boolean finalRun, BatchRuns batchRuns) {
        String sql = "select count(*) from (" + queries.getAdditionalMdmPartiesTxnImpacted() + ")";
        return template.query(sql, getAdditionalMdmPartiesTxnImpactedParams(finalRun, batchRuns), intRse);
    }

    // count previous errors to retry
    public int countPreviousErrorsMdmParties(boolean finalRun, BatchRuns batchRuns) {
        String sql = "select count(*) from (" + queries.getPreviousErrorsMdmParties() + ")";
        return template.query(sql, getPreviousErrorsMdmPartiesParams(finalRun, batchRuns), intRse);
    }

    /**
     * Returns 0 if no transaction ID found.
     */
    public int getMaxTxnIdByAge(Duration d) {
        return ofNullable(
            template.queryForObject(queries.getMaxTxnIdByTime(), singletonMap("txnTime", valueOf(now().minus(d))), Integer.class))
            .orElseGet(() -> 0);
    }

}