package au.com.iag.customer.tenure.repository;

import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;

import au.com.iag.customer.tenure.domain.ProcessedPartyGroupBatchRun;
import au.com.iag.customer.tenure.domain.ProcessingStage;
import au.com.iag.customer.tenure.domain.WarningType;

@Component
public class ProcessedPartyGroupBatchRunCustomRepositoryImpl implements ProcessedPartyGroupBatchRunCustomRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void insertWithQuery(ProcessedPartyGroupBatchRun processedPartyGroupBatchRun) {
        entityManager.createNativeQuery("insert into temp.processed_party_group_batch_run (party_grp_id, batch_run_id, mdm_id, request, response, http_response_status, warning_type_id, processing_stage_id, processed_time) values (?, ?, ?, ?, ?, ?, ?, ?, ?)")
            .setParameter(1, processedPartyGroupBatchRun.getPartyGroupId())
            .setParameter(2, processedPartyGroupBatchRun.getBatchRunId())
            .setParameter(3, processedPartyGroupBatchRun.getMdmId())
            .setParameter(4, processedPartyGroupBatchRun.getRequest())
            .setParameter(5, processedPartyGroupBatchRun.getResponse())
            .setParameter(6, processedPartyGroupBatchRun.getHttpResponseStatus())
            .setParameter(7, ofNullable(processedPartyGroupBatchRun.getWarningType()).map(WarningType::getId).orElseGet(() -> null))
            .setParameter(8, of(processedPartyGroupBatchRun.getProcessingStage()).map(ProcessingStage::getId).get())
            .setParameter(9, processedPartyGroupBatchRun.getProcessedTime())
            .executeUpdate();
    }

}
