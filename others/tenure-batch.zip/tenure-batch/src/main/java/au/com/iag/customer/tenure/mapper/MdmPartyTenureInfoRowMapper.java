package au.com.iag.customer.tenure.mapper;

import static java.util.Optional.ofNullable;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.jdbc.core.RowMapper;

import au.com.iag.customer.tenure.dto.MdmPartyTenureInfoDto;
import au.com.iag.customer.tenure.util.DateUtil;

public class MdmPartyTenureInfoRowMapper implements RowMapper<MdmPartyTenureInfoDto> {

    @Override
    public MdmPartyTenureInfoDto mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        int partyGroupId = resultSet.getInt("party_grp_id");
        String mdmId = resultSet.getString("mdm_id");
        Integer tenureId = resultSet.getInt("loy_relationship_id");
        if (resultSet.wasNull()) {
            tenureId = null;
        }
        BigDecimal lockedInDiscount = resultSet.getBigDecimal("locked_in_discount");
        if (resultSet.wasNull()) {
            lockedInDiscount = null;
        }
        LocalDate tenureCommencementDate = ofNullable(resultSet.getDate("rel_commence_date")).map(DateUtil::dateToLocalDate).orElseGet(() -> null);
        String referenceNo = resultSet.getString("reference_no");
        String overrideReason = resultSet.getString("override_reason");
        LocalDate tenureExpiryDate = ofNullable(resultSet.getDate("rel_expiry_date")).map(DateUtil::dateToLocalDate).orElseGet(() -> null);
        Integer txnId = resultSet.getInt("transaction_id");
        if (resultSet.wasNull()) {
            txnId = null;
        }
        LocalDateTime txnDateTime = ofNullable(resultSet.getDate("tran_timestamp")).map(DateUtil::dateToLocalDateTimeWithMillis).orElseGet(() -> null);
        String extRef = resultSet.getString("ext_ref");
        return new MdmPartyTenureInfoDto(partyGroupId, mdmId, tenureId, lockedInDiscount, tenureCommencementDate, tenureExpiryDate, referenceNo, overrideReason, txnId, txnDateTime, extRef);
    }
}
