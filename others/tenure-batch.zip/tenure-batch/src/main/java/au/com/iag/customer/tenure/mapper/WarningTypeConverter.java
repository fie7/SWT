package au.com.iag.customer.tenure.mapper;

import static au.com.iag.customer.tenure.domain.WarningType.values;
import static java.util.Optional.ofNullable;
import static java.util.stream.Stream.of;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import au.com.iag.customer.tenure.domain.WarningType;

@Converter(autoApply = true)
public class WarningTypeConverter implements AttributeConverter<WarningType, Integer> {
 
    @Override
    public Integer convertToDatabaseColumn(WarningType warningType) {
        if (warningType == null) {
            return null;
        }
        return warningType.getId();
    }

    @Override
    public WarningType convertToEntityAttribute(Integer id) {
        /*
        if (id == null) {
            return null;
        }

        return Stream.of(WarningType.values())
          .filter(w -> w.getId().equals(id))
          .findFirst()
          .orElseThrow(IllegalArgumentException::new);
        */
        
        return ofNullable(id).map(i -> of(values()).filter(i::equals).findFirst().orElseThrow(IllegalArgumentException::new)).orElseGet(() -> null);
    }
}