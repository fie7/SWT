package au.com.iag.customer.tenure.util;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;
import static java.time.LocalDateTime.now;
import static java.time.temporal.ChronoUnit.SECONDS;
import static java.util.Arrays.asList;
import static java.util.Optional.of;
import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.time.LocalDateTime;
import java.util.Collections;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.http.HttpEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
@Component
public class TokenSet {

    private static final RestTemplate restTemplate;

    static {
        ObjectMapper mapper = new  ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.setSerializationInclusion(NON_NULL);
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        /*
        restTemplate = new RestTemplateBuilder()
            .defaultHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
            .messageConverters(new MappingJackson2HttpMessageConverter(mapper))
            .build();
        */
        restTemplate = restTemplate();
        restTemplate.setMessageConverters(Collections.singletonList(new MappingJackson2HttpMessageConverter(mapper)));
        restTemplate.setInterceptors(asList(new HttpHeaderInterceptor(CONTENT_TYPE, APPLICATION_JSON_VALUE), new HttpHeaderInterceptor(ACCEPT, APPLICATION_JSON_VALUE)));
    }

    // buffer for jwt expiry time period (in minutes)
    private static final int BUFFER_EXPIRY_MINS = 1;

    @JsonIgnore
    //@Value("${svx.jwt.expiry.mins}")
    //@Setter(value=NONE)
    private int expiryMins;
    
    @JsonIgnore
    //@Value("${svx.jwt.auth.refresh.end.point}")
    //@Setter(value=NONE)
    private String refreshEndPoint;

    @Data
    @AllArgsConstructor
    private class RefreshToken {
        private String refreshToken;
    }
    
    private String jwt;
    private String refreshToken;

    @JsonIgnore
    private LocalDateTime tokenLastRefreshTime;

    private static RestTemplate restTemplate() {
        try {
            TrustStrategy acceptingTrustStrategy = (x509Certificates, s) -> true;
            SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
            SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext, new NoopHostnameVerifier());
            CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();
            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
            requestFactory.setHttpClient(httpClient);
            RestTemplate restTemplate = new RestTemplate(requestFactory);
            return restTemplate;
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public static RestTemplate getRestTemplate() {
        return restTemplate;
    }

    public TokenSet refreshIfRequired() {
        if (SECONDS.between(tokenLastRefreshTime, now()) > ((expiryMins - BUFFER_EXPIRY_MINS) * 60)) {
            // refresh token and store

            log.info("refreshing JWT token...");
            LocalDateTime startTime = now();
            TokenSet tokenSet = of(restTemplate.exchange(refreshEndPoint, POST, new HttpEntity<>(new RefreshToken(refreshToken)), TokenSet.class))
                .map(resp -> resp.getStatusCode().is2xxSuccessful() ? resp.getBody() : null)
                .orElseThrow(() -> new RuntimeException("Error refreshing JWT token!"));

            // update current tokens
            jwt = tokenSet.getJwt();
            refreshToken = tokenSet.getRefreshToken();
            tokenLastRefreshTime = startTime;
        }
        return this;
    }
}  // TokenSet
