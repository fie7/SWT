package au.com.iag.customer.tenure.dao;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TenureQueries {

    @Value("${tenure.additional.mdm.parties}")
    private String additionalMdmParties;
    
    @Value("${tenure.additional.mdm.parties.txn.impacted}")
    private String additionalMdmPartiesTxnImpacted;

    @Value("${tenure.previous.errors.mdm.parties}")
    private String previousErrorsMdmParties;

    @Value("${tenure.max.txn.id.by.time}")
    private String maxTxnIdByTime;

    public String getAdditionalMdmParties() {  // blue delta
        return additionalMdmParties;
    }
    
    public String getAdditionalMdmPartiesTxnImpacted() {  // red delta
        return additionalMdmPartiesTxnImpacted;
    }
    
    public String getPreviousErrorsMdmParties() {
        return previousErrorsMdmParties;
    }

    public String getMaxTxnIdByTime() {
        return maxTxnIdByTime;
    }
}