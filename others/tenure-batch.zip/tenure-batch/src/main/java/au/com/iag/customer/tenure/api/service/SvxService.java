package au.com.iag.customer.tenure.api.service;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;
import static java.util.Objects.requireNonNull;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static lombok.AccessLevel.NONE;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.time.LocalDateTime;
import java.util.Optional;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import au.com.iag.customer.tenure.api.model.TenurePostRequest;
import au.com.iag.customer.tenure.api.model.TenurePostResponse;
import au.com.iag.customer.tenure.util.TokenSet;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@NoArgsConstructor
public class SvxService {

    private static final RestTemplate restTemplate;
    
    @Value("${svx.jwt.auth.end.point}")
    private String authEndPoint;

    @Value("${svx.jwt.expiry.mins}")
    private int expiryMins;
    
    @Value("${svx.jwt.auth.refresh.end.point}")
    private String refreshEndPoint;
    
    @Value("${svx.tenure.end.point}")
    private String tenureEndPoint;

    @Value("${svx.user.name}")
    private String username;

    @Value("${svx.user.pwd}")
    private String password;

    static {
        ObjectMapper mapper = new  ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.setSerializationInclusion(NON_NULL);
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        // HTTP
        restTemplate = new RestTemplateBuilder()
            .defaultHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
            .messageConverters(new MappingJackson2HttpMessageConverter(mapper))
            .build();
        /*
        // HTTPS
        restTemplate = getRestTemplate();
        restTemplate.setMessageConverters(Collections.singletonList(new MappingJackson2HttpMessageConverter(mapper)));
        restTemplate.setInterceptors(asList(new HttpHeaderInterceptor(CONTENT_TYPE, APPLICATION_JSON_VALUE), new HttpHeaderInterceptor(ACCEPT, APPLICATION_JSON_VALUE)));
        */
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    private class Credential {
        @Setter(value=NONE)
        private String username;

        @Setter(value=NONE)
        private String password;
    }

    @Data
    @AllArgsConstructor
    public class TenureResponseWithStatus {
        private HttpStatus status;
        private TenurePostResponse response;
    }

    /*
    @Data
    @AllArgsConstructor
    private class RefreshToken2 {
        private String refreshToken;
    }

    @Data
    private class TokenSet2 {
        // buffer for jwt expiry time period (in minutes)
        private static final int BUFFER_EXPIRY_MINS = 1;
        
        private String jwt;
        private String refreshToken;

        @JsonIgnore
        private LocalDateTime tokenLastRefreshTime;

        @JsonIgnore
        @Value("${svx.jwt.expiry.mins}")
        @Setter(value=NONE)
        private int expiryMins;
        
        @JsonIgnore
        @Value("${svx.jwt.auth.refresh.end.point}")
        @Setter(value=NONE)
        private String refreshEndPoint;

        public TokenSet refreshIfRequired() {
            if (ChronoUnit.MINUTES.between(tokenLastRefreshTime, LocalDateTime.now()) > (expiryMins - BUFFER_EXPIRY_MINS)) {
                // refresh token and store

                log.info("refreshing JWT token...");
                LocalDateTime startTime = LocalDateTime.now();
                TokenSet tokenSet = of(restTemplate.exchange(refreshEndPoint, POST, new HttpEntity<>(new RefreshToken(refreshToken)), TokenSet.class))
                    .map(resp -> resp.getStatusCode().is2xxSuccessful() ? resp.getBody() : null)
                    .orElseThrow(() -> new RuntimeException("Error refreshing JWT token!"));

                // update current tokens
                jwt = tokenSet.getJwt();
                refreshToken = tokenSet.getRefreshToken();
                tokenLastRefreshTime = startTime;
            }
            return this;
        }
    }  // TokenSet
    */

    private Optional<TokenSet> tokenSet = empty();

    private static RestTemplate getRestTemplate() {
        try {
            TrustStrategy acceptingTrustStrategy = (x509Certificates, s) -> true;
            SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
            SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext, new NoopHostnameVerifier());
            CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();
            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
            requestFactory.setHttpClient(httpClient);
            RestTemplate restTemplate = new RestTemplate(requestFactory);
            return restTemplate;
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Creates a new JWT token and stores it. 
     * @return a new JWT token
     */
    private TokenSet newJwt() {
        log.info("getting a new JWT token...");
        LocalDateTime startTime = LocalDateTime.now();
        TokenSet tokenSet = of(TokenSet.getRestTemplate().exchange(authEndPoint, POST, new HttpEntity<>(new Credential(username, password)), TokenSet.class))
            .map(resp -> resp.getStatusCode().is2xxSuccessful() ? resp.getBody() : null)
            .orElseThrow(() -> new RuntimeException("Error getting a new JWT token!"));
        tokenSet.setTokenLastRefreshTime(startTime);
        tokenSet.setExpiryMins(expiryMins);
        tokenSet.setRefreshEndPoint(refreshEndPoint);
        this.tokenSet = of(tokenSet);
        return tokenSet;
    }

    /**
     * Returns a new JWT token if absent or a refreshed one if the current one is deemed to be 'about to expire' 
     */
    private String getJwt() {
        synchronized (tokenSet) {
            return tokenSet.map(TokenSet::refreshIfRequired).orElseGet(this::newJwt).getJwt();
        }
    }

    private TenureResponseWithStatus toTenureResponseWithStatus(ResponseEntity<TenurePostResponse> resp) {
        requireNonNull(resp);
        return new TenureResponseWithStatus(resp.getStatusCode(), resp.getBody());
    }

    /**
     * Calls an SVx tenure API and returns a tenure response for a given MDM party ID
     * 
     * @param   request
     * @return  a {@link TenurePostResponse} response for a given MDM party ID
     */
    public TenureResponseWithStatus getTenureDates(TenurePostRequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(getJwt());

        return of(TokenSet.getRestTemplate().exchange(tenureEndPoint, POST, new HttpEntity<>(request, headers), TenurePostResponse.class))
            .map(this::toTenureResponseWithStatus).get();
        /*
            .map(resp -> resp.getStatusCode().is2xxSuccessful() ? resp.getBody() : null)
            .orElseThrow(() -> new RuntimeException("Error calling SVx tenure API!"));
        */
    }
}
