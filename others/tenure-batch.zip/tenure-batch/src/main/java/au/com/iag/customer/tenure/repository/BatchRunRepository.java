package au.com.iag.customer.tenure.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import au.com.iag.customer.tenure.domain.BatchRun;

public interface BatchRunRepository extends CrudRepository<BatchRun, Integer> {
    
    public Optional<BatchRun> findTopByOrderByIdDesc();

}
