package au.com.iag.customer.tenure.api.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TenurePostRequest {

    private String party_id;

    private CustomerRelationship customer_relationship;

    private List<ExternalReference> external_references;

}
