create table temp.processed_party_group (
  party_grp_id integer not null primary key
);

create table temp.batch_run (
  id integer not null primary key
  , max_txn_id integer not null
  , start_time timestamp not null
  , txn_id integer not null
);

create table temp.processed_party_group_batch_run (
  id integer generated always as identity primary key
  , party_grp_id integer not null
  , batch_run_id integer not null
  , mdm_id varchar(10) not null
  , processed_time timestamp not null
  , foreign key (party_grp_id) references temp.processed_party_group(party_grp_id)
  , foreign key (batch_run_id) references temp.batch_run (id)
  , constraint c1 unique (party_grp_id, batch_run_id)
);
