/*
Copyright (c) 2023 Ferry Ie. All rights reserved.
*/

package au.com.im30.viz.controller;

import java.time.LocalDate;
import java.util.List;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import au.com.im30.viz.dao.dto.AssetDto;
import au.com.im30.viz.dao.service.AssetService;
import au.com.im30.viz.model.GChartDataTable;
import au.com.im30.viz.model.GChartDataTable.Col;
import au.com.im30.viz.model.GChartDataTable.ColDef;
import au.com.im30.viz.model.GChartDataTable.ColType;
import au.com.im30.viz.model.GChartDataTable.Row;

@RestController
public class AssetController {

    private final AssetService service;

    public AssetController(AssetService service) {
        this.service = service;
    }

    @GetMapping("/assets")
    public List<AssetDto> findAll(@RequestParam(required = false) Long id) {
    	if (ofNullable(id).isPresent()) {
    		return service.findAllById(id);
    	} else {
    		return service.findAll();
    	}
    }
    
    private AssetDto enhanceName(AssetDto asset, List<String> names) {
    	if (names.stream().filter(n -> n.equals(asset.getName())).findFirst().isPresent()) {
    		return new AssetDto(asset.getId(), asset.getName() + " \u221E", asset.getDescription(), asset.getStartDate(), asset.getEndDate());
    	} else {
    		return asset;
    	}
    }

    private List<AssetDto> enhanceNamesForOpenEndDateAssets(List<AssetDto> assets) {
    	List<String> openEndDateAssetNames = assets.stream().filter(a -> a.getEndDate().equals(LocalDate.of(9999, 12, 31)))
    		.map(a -> a.getName()).collect(Collectors.toList());
    	return assets.stream().map(a -> {return enhanceName(a, openEndDateAssetNames);}).collect(Collectors.toList());
    }

    @GetMapping("/assetsDt")
    public GChartDataTable toDataTable(@RequestParam(required = false) Long id) {
    	List<AssetDto> assets = enhanceNamesForOpenEndDateAssets(findAll(id));
    	if (assets.size() > 0) {
			return GChartDataTable.of(o -> new ColDef[] {
					new ColDef("Asset Name", null, ColType.STRING)
					, new ColDef("Version", null, ColType.STRING)
					, new ColDef("Start", null, ColType.DATE)
					, new ColDef("End", null, ColType.DATE)				
				}, o -> of(o).map(AssetDto.class::cast).map(a -> new Row(new Col[] {
						new Col(a.getName(), null)
						, new Col(a.getDescription(), null)
						, new Col(a.getStartDate(), null)
						, new Col(a.getEndDate(), null)
					})).get()
				, assets);
    	} else {
    		return null;
    	}
    }

}