package au.com.iag.viz.dao;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SrcSysBusQueries {

    @Value("${src_sys_bus.query.find.all.by.id}")
    private String findAllById;

    public String getFindAllById() {
        return findAllById;
    }
}