package au.com.iag.viz.controller;

import static java.util.Optional.of;

import java.lang.reflect.Array;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import au.com.im30.viz.dao.dto.AssetDto;
import au.com.im30.viz.model.GChartDataTable;
import au.com.im30.viz.model.GChartDataTable.Col;
import au.com.im30.viz.model.GChartDataTable.ColDef;
import au.com.im30.viz.model.GChartDataTable.ColType;
import au.com.im30.viz.model.GChartDataTable.ColumnRole;
import au.com.im30.viz.model.GChartDataTable.Row;

@RestController
public class CompleteBusinessController {

    private final SrcSysBusController srcSysBusController;
    private final BusRoleRelController busRoleRelController;

    public CompleteBusinessController(SrcSysBusController srcSysBusController, BusRoleRelController busRoleRelController) {
        this.srcSysBusController = srcSysBusController;
        this.busRoleRelController = busRoleRelController;
    }

    private static <T> T[] concatWithStream(T[] array1, T[] array2) {
        return Stream.concat(Arrays.stream(array1), Arrays.stream(array2))
          .toArray(size -> (T[]) Array.newInstance(array1.getClass().getComponentType(), size));
    }

    /*
    private GChartDataTable combine(GChartDataTable dt1, GChartDataTable dt2) {
        ColDef[] colDefs = null;
        Row[] rows = null;

        if (dt1 != null) {
            colDefs = dt1.getCols().toArray(new ColDef[0]);
            rows = dt1.getRows().toArray(new Row[0]);
        }
        
        if (dt2 != null) {
            if (colDefs == null) {
                colDefs = dt2.getCols().toArray(new ColDef[0]);
                rows = dt2.getRows().toArray(new Row[0]);
            } else {
                rows = concatWithStream(rows, dt2.getRows().toArray(new Row[0]));
            }
        }
        
        if (colDefs == null) {
            return null;
        } else {
            return new GChartDataTable(colDefs, rows);
        }
    }
    */

    @GetMapping("/completeBusinessDt")
    public GChartDataTable toDataTable(@RequestParam(required = false) Long id) {
        List<AssetDto> dtos = srcSysBusController.getDtosForCharting(id);
        Optional<LocalDate> srcSysBusOpenDateForCharting = Optional.empty(); 
        Optional<AssetDto> openDatedAssetForCharting = dtos.stream().filter(AssetDto::isDummy).findFirst();
        if (openDatedAssetForCharting.isPresent()) {
            srcSysBusOpenDateForCharting = Optional.of(openDatedAssetForCharting.get().getEndDate());
        }
        dtos.addAll(busRoleRelController.getDtosForCharting(id, srcSysBusOpenDateForCharting));
        
        ColDef tooltip = new ColDef("", null, ColType.STRING);
        tooltip.addRole(ColumnRole.TOOLTIP);
        
        if (dtos.isEmpty()) {
            return null;
        } else {
            return GChartDataTable.of(o -> new ColDef[] {
                    new ColDef("Asset Name", null, ColType.STRING)
                    , new ColDef("Description", null, ColType.STRING)
                    , tooltip
                    , new ColDef("Start", null, ColType.DATE)
                    , new ColDef("End", null, ColType.DATE)             
                }, o -> of(o).map(AssetDto.class::cast).map(a -> new Row(new Col[] {
                        new Col(a.getName(), null)
                        , new Col(a.getDescription(), null)
                        , new Col(a.getTooltip(), null)
                        , new Col(a.getStartDate(), null)
                        , new Col(a.getEndDate(), null)
                    })).get()
                , dtos);
        }
        //return combine(srcSysBusController.toDataTable(id), busRoleRelController.toDataTable(id));
    }

}