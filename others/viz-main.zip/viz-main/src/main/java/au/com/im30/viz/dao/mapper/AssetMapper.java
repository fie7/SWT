/*
Copyright (c) 2023 Ferry Ie. All rights reserved.
*/

package au.com.im30.viz.dao.mapper;

import au.com.im30.viz.dao.dto.AssetDto;
import au.com.im30.viz.dao.model.Asset;

public class AssetMapper {
    public static Asset toEntity(AssetDto dto) {
    	return new Asset(dto.getId(), dto.getName(), dto.getDescription(), dto.getStartDate(), dto.getEndDate());
    }

    public static AssetDto toDto(Asset asset) {
    	return new AssetDto(asset.getId(), asset.getName(), asset.getDescription(), asset.getStartDate(), asset.getEndDate());
    }
}
