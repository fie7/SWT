package au.com.iag.viz.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import au.com.iag.viz.dao.mapper.BusRoleRelRowMapper;
import au.com.iag.viz.dao.model.BusRoleRel;

@Repository
public class BusRoleRelDao {

    private final NamedParameterJdbcTemplate template;
    private final BusRoleRelQueries queries;
    private final RowMapper<BusRoleRel> rowMapper;

    @Autowired
    public BusRoleRelDao(NamedParameterJdbcTemplate template, BusRoleRelQueries queries) {
        this.template = template;
        this.rowMapper = new BusRoleRelRowMapper();
        this.queries = queries;
    }

    public Stream<BusRoleRel> findAllById(long id) {
        String sql = queries.getFindAllById();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("id", id);
        return template.query(sql, paramMap, rowMapper).stream();
    }

}