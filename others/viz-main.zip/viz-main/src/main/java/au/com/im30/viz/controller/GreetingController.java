package au.com.im30.viz.controller;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class GreetingController {

	@GetMapping("/greeting")
	public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("name", name);
		return "greeting";
	}
	
	@GetMapping(value="/testTxt", produces=MediaType.TEXT_PLAIN_VALUE)
	public @ResponseBody String test() {
		//return "{cols:[{id:'Position',type:'string'},{id:'Name',type:'string'},{id:'Start',type:'date'},{id:'End',type:'date'}],rows:[{c:[{v:'President',f:'President'},{v:'George Washington',f:'George Washington'},{v:new Date(1789, 3, 30),f:'30/03/1789'},{v:new Date(1797, 2, 4),f:'04/02/1797'}]},{c:[{v:'President',f:'President'},{v:'John Adams',f:'John Adams'},{v:new Date(1797, 2, 4),f:'04/02/1797'},{v:new Date(1801, 2, 4),f:'04/02/1801'}]},{c:[{v:'President',f:'President'},{v:'Thomas Jefferson',f:'Thomas Jefferson'},{v:new Date(1801, 2, 4),f:'04/02/1801'},{v:new Date(1809, 2, 4),f:'04/02/1809'}]}]}";
		return "{\"cols\":[{\"id\":\"Position\",\"type\":\"string\"},{\"id\":\"Name\",\"type\":\"string\"},{\"id\":\"Start\",\"type\":\"date\"},{\"id\":\"End\",\"type\":\"date\"}],\"rows\":[{\"c\":[{\"v\":\"President\",\"f\":\"President\"},{\"v\":\"George Washington\",\"f\":\"George Washington\"},{\"v\":\"Date(1789, 3, 30)\",\"f\":\"30/03/1789\"},{\"v\":\"Date(1797, 2, 4)\",\"f\":\"04/02/1797\"}]},{\"c\":[{\"v\":\"President\",\"f\":\"President\"},{\"v\":\"John Adams\",\"f\":\"John Adams\"},{\"v\":\"Date(1797, 2, 4)\",\"f\":\"04/02/1797\"},{\"v\":\"Date(1801, 2, 4)\",\"f\":\"04/02/1801\"}]},{\"c\":[{\"v\":\"President\",\"f\":\"President\"},{\"v\":\"Thomas Jefferson\",\"f\":\"Thomas Jefferson\"},{\"v\":\"Date(1801, 2, 4)\",\"f\":\"04/02/1801\"},{\"v\":\"Date(1809, 2, 4)\",\"f\":\"04/02/1809\"}]}]}";
	}

	public static void main(String[] args) {
		System.out.println(MessageFormat.format("{0,number,$'#',##}", 2));
		System.out.println(MessageFormat.format("{0,date,yyyy-MM-dd HH:mm:ss.SSS}", Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant())));
		System.out.println(MessageFormat.format("{0}", true));
		System.out.println(MessageFormat.format("''{0}''", "test"));
		System.out.println(Date.from(LocalDate.parse("1789-01-01").atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()));
		System.out.println();
	}

}