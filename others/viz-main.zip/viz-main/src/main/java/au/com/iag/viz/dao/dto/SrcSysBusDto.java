package au.com.iag.viz.dao.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SrcSysBusDto {
	private long id;
	private String ssbReference;
	private String businessTypeCode;
	private String holdingBusinessId;
	private int version;
	private String statusCode;
	private String displayLevel2;
	private LocalDate startDate;
	private LocalDate endDate;
	private long txnId;
	private String txnTypeCode;
	private String txnSubTypeCode;
	private String userId;
}
