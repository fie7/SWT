package au.com.iag.viz.controller;

import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import au.com.iag.viz.dao.dto.BusRoleRelDto;
import au.com.iag.viz.dao.service.BusRoleRelService;
import au.com.im30.viz.dao.dto.AssetDto;
import au.com.im30.viz.model.GChartDataTable;
import au.com.im30.viz.model.GChartDataTable.Col;
import au.com.im30.viz.model.GChartDataTable.ColDef;
import au.com.im30.viz.model.GChartDataTable.ColType;
import au.com.im30.viz.model.GChartDataTable.Row;
import au.com.im30.viz.util.DateUtil;

@RestController
public class BusRoleRelController {

    private final BusRoleRelService service;

    public BusRoleRelController(BusRoleRelService service) {
        this.service = service;
    }

    @GetMapping("/businessPartyRoles")
    public List<BusRoleRelDto> findAllById(@RequestParam(required = false) Long id) {
    	if (ofNullable(id).isPresent()) {
    		return service.findAllById(id);
    	} else {
    		return Collections.emptyList();
    	}
    }

    private String getDateRange(BusRoleRelDto dto) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        boolean openEndDate = dto.getEndDate().isEqual(LocalDate.of(9999, 12, 31));
        return sdf.format(DateUtil.localDateToDate(dto.getStartDate())) + " - " + (openEndDate ? "\u221E" : sdf.format(DateUtil.localDateToDate(dto.getEndDate()))); 
    }
    
    private String getDuration(BusRoleRelDto dto) {
        if (dto.getEndDate().isEqual(LocalDate.of(9999, 12, 31))) {
            return "\u221E";
        }
        Period diff = Period.between(dto.getStartDate(), dto.getEndDate());
        int diffYears = diff.getYears();
        int diffMonths = diff.getMonths();
        int diffDays = diff.getDays();
        return (diffYears > 0 ? diffYears + " year(s) " : "") + (diffMonths > 0 ? diffMonths + " month(s) " : "") + (diffDays > 0 ? diffDays + " day(s) " : ""); 
    }
    
    private String generateTooltip(BusRoleRelDto dto) {
        String template = "<b>Role [%s]</b><div class='google-visualization-tooltip-separator'></div><b>Period: </b>[%s]<br/>"
            + "<b>Duration: </b>%s<br/><div class='google-visualization-tooltip-separator'></div>"
            + "<b>Version: </b>%s<br/><b>User: </b>%s";
        return String.format(template, dto.getPartyBusinessRoleCode().trim(), getDateRange(dto), getDuration(dto), dto.getVersion(), dto.getUserId());
    }

    private AssetDto toAssetDto(BusRoleRelDto dto) {
        return new AssetDto((int) dto.getId(), "Role [" + dto.getPartyBusinessRoleCode().trim() + "]", "", dto.getStartDate(), dto.getEndDate(), generateTooltip(dto), false);
    }

    private List<AssetDto> toAssetDtos(List<BusRoleRelDto> dtos) {
        return dtos.stream().map(this::toAssetDto).collect(Collectors.toList());
    }
    
    private List<AssetDto> addOpenDateRowForCharting(List<AssetDto> dtos, Optional<LocalDate> srcSysBusOpenDateForCharting) {
/*
        long plotableCount = dtos.stream().filter(d -> d.getEndDate().isAfter(d.getStartDate()) && !d.getEndDate().isEqual(LocalDate.of(9999, 12, 31)))
            .count();
        if (plotableCount > 0) {
            return dtos;  // no change
        } else {
*/
            List<AssetDto> dtoz = dtos.stream().filter(d -> d.getEndDate().isEqual(LocalDate.of(9999, 12, 31))).collect(Collectors.toList());
            if (dtoz.size() > 0) {
                // create new rows to represent open dated record
                return Stream.concat(dtoz.stream().map(d -> new AssetDto(0, d.getName(), d.getDescription(), d.getStartDate(), srcSysBusOpenDateForCharting.isPresent() ? srcSysBusOpenDateForCharting.get() : d.getStartDate().plusYears(1), d.getTooltip(), true))
                    , dtos.stream()).collect(Collectors.toList());
                /*
                // create a new row to represent open dated record
                AssetDto newDto = new AssetDto(0, dto.get().getName(), dto.get().getDescription(), dto.get().getStartDate(), dto.get().getStartDate().plusYears(1));
                return Stream.concat(Stream.of(newDto), dtos.stream()).collect(Collectors.toList());
                */
            } else {
                return dtos;
            }
//        }
    }

    private AssetDto enhanceName(AssetDto asset, List<String> names) {
    	if (names.stream().filter(n -> n.equals(asset.getName())).findFirst().isPresent()) {
    		return new AssetDto(asset.getId(), asset.getName() + " \u221E", asset.getDescription(), asset.getStartDate(), asset.getEndDate(), asset.getTooltip(), asset.isDummy());
    	} else {
    		return asset;
    	}
    }

    private List<AssetDto> enhanceNamesForOpenEndDateAssets(List<AssetDto> assets) {
    	List<String> openEndDateAssetNames = assets.stream().filter(a -> a.getEndDate().equals(LocalDate.of(9999, 12, 31)))
    		.map(a -> a.getName()).collect(Collectors.toList());
    	return assets.stream().map(a -> {return enhanceName(a, openEndDateAssetNames);}).collect(Collectors.toList());
    }

    public List<AssetDto> getDtosForCharting(Long id, Optional<LocalDate> srcSysBusOpenDateForCharting) {
        return enhanceNamesForOpenEndDateAssets(addOpenDateRowForCharting(toAssetDtos(findAllById(id).stream().filter(d -> d.getEndDate().isAfter(d.getStartDate())).collect(Collectors.toList())), srcSysBusOpenDateForCharting));
    }

    @GetMapping("/businessPartyRolesDt")
    public GChartDataTable toDataTable(@RequestParam(required = false) Long id) {
        List<AssetDto> assets = enhanceNamesForOpenEndDateAssets(addOpenDateRowForCharting(toAssetDtos(findAllById(id).stream().filter(d -> d.getEndDate().isAfter(d.getStartDate())).collect(Collectors.toList())), Optional.empty()));

    	if (assets.size() > 0) {
			return GChartDataTable.of(o -> new ColDef[] {
					new ColDef("Asset Name", null, ColType.STRING)
					, new ColDef("Description", null, ColType.STRING)
					, new ColDef("Start", null, ColType.DATE)
					, new ColDef("End", null, ColType.DATE)				
				}, o -> of(o).map(AssetDto.class::cast).map(a -> new Row(new Col[] {
						new Col(a.getName(), null)
						, new Col(a.getDescription(), null)
						, new Col(a.getStartDate(), null)
						, new Col(a.getEndDate(), null)
					})).get()
				, assets);
    	} else {
    		return null;
    	}
    }

}