/*
Copyright (c) 2023 Ferry Ie. All rights reserved.
*/

package au.com.im30.viz.model;

import static au.com.im30.viz.util.DateUtil.localDateTimeToDate;
import static au.com.im30.viz.util.DateUtil.localDateToDate;
import static au.com.im30.viz.util.DateUtil.localTimeToDate;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;
import static java.lang.String.format;
import static java.util.Arrays.asList;
import static java.util.Arrays.stream;
import static java.util.Objects.requireNonNull;
import static java.util.Optional.ofNullable;
import static java.util.stream.IntStream.range;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Getter
@JsonInclude(NON_NULL)
public class GChartDataTable {

	@Getter
	@AllArgsConstructor
	public static enum ColType {
		STRING(String.class, "string", "%s", o -> new Object[] {o}, "{0}", o -> new Object[] {o})
		, NUMBER(Number.class, "number", "%s", o -> new Object[] {o}, "{0}", o -> new Object[] {o})
		, BOOLEAN(Boolean.class, "boolean", "%s", o -> new Object[] {o}, "{0}", o -> new Object[] {o})
		, DATE(LocalDate.class, "date", "Date(%s, %s, %s)", o -> {
				LocalDate ld = (LocalDate) o;
				return new Object[] {ld.getYear(), ld.getMonthValue() - 1, ld.getDayOfMonth()};
			}, "{0,date}", ColType::ldToDate)
		, DATE_TIME(LocalDateTime.class, "datetime", "Date(%s, %s, %s, %s, %s, %s)", o -> {
				LocalDateTime ldt = (LocalDateTime) o;
				return new Object[] {
					ldt.getYear(), ldt.getMonthValue() - 1, ldt.getDayOfMonth()
					, ldt.getHour(), ldt.getMinute(), ldt.getSecond()};
			}, "{0,date,yyyy-MM-dd HH:mm:ss.SSS}", ColType::ldtToDate)
		, TIME_OF_DAY(LocalTime.class, "timeofday", "[%s, %s, %s, %s]", o -> {
				LocalTime lt = (LocalTime) o;
				return new Object[] {lt.getHour(), lt.getMinute(), lt.getSecond(), lt.getNano()};
			}, "{0,time}", ColType::ltToDate);

		private Class<?> clazz;
		private String type;
		private String vFormat;  // format pattern for the 'v' field. See {@link java.lang.String#format(String, Object[])} for its pattern.
		private Function<Object, Object[]> vFunct;
		private String fFormat;  // format pattern for the 'f' field. See {@link java.text.Format} for its pattern.
		private Function<Object, Object[]> fFunct;
		
		public <T> String toColV(T arg) {
			requireNonNull(arg);
			if (! clazz.isInstance(arg)) {
				throw new RuntimeException(format("Argument %s must be of type %s", arg, clazz.getSimpleName()));
			}
			return format(vFormat, vFunct.apply(arg));
		}

		public <T> String toColF(T arg) {
			requireNonNull(arg);
			if (! clazz.isInstance(arg)) {
				throw new RuntimeException(format("Argument %s must be of type %s", arg, clazz.getSimpleName()));
			}
			return MessageFormat.format(fFormat, fFunct.apply(arg));
		}
		
		public <T> String toColF(String fFormat, T arg) {
			requireNonNull(arg);
			if (! clazz.isInstance(arg)) {
				throw new RuntimeException(format("Argument %s must be of type %s", arg, clazz.getSimpleName()));
			}
			return MessageFormat.format(fFormat, fFunct.apply(arg));
		}
		
		public Optional<ColType> of(Class<?> clazz) {
			return stream(ColType.values()).filter(ct -> ct.clazz == clazz).findFirst();
		}
		private static <T> Object[] ldToDate(T ld) {
			return new Date[] {localDateToDate((LocalDate) ld)};
		}

		private static <T> Object[] ldtToDate(T ldt) {
			return new Date[] {localDateTimeToDate((LocalDateTime) ldt)};
		}

		private static <T> Object[] ltToDate(T lt) {
			return new Date[] {localTimeToDate((LocalTime) lt)};
		}
	}
	
	@Getter
	@AllArgsConstructor
	public static enum ColumnRole {
		ANNOTATION("annotation")
		, ANNOTATION_TEXT("annotationText")
		, CERTAINTY("certainty")
		, EMPHASIS("emphasis")
		, INTERVAL("interval")
		, SCOPE("scope")
		, STYLE("style")
		, TOOLTIP("tooltip");

		private String val;
	}
	
	@Getter
	@JsonInclude(NON_NULL)
	public static class ColDef {
		private String id;
		private String label;
		@JsonIgnore
		private ColType colType;
		@NonNull
		private String type;
		private String pattern;
		private Map<String, String> p;
		
		public ColDef(String id, String label, ColType colType) {
			this.id = id;
			this.label = label;
			this.colType = colType;
			this.type = colType.getType();
		}
		
		public ColDef(String id, String label, ColType colType, String pattern) {
			this(id, label, colType);
			this.pattern = pattern;
		}

		public ColDef(String id, String label, ColType colType, String pattern, Map<String, String> p) {
			this(id, label, colType, pattern);
			this.p = p;
		}
		
		public ColDef addProperty(String key, String val) {
			requireNonNull(key);
			p = ofNullable(p).orElseGet(() -> new HashMap<>());
			p.put(key, val);
			return this;
		}
		
		public ColDef addRole(ColumnRole role) {
			return addProperty("role", role.getVal());
		}
		
		public ColDef addStyle(String style) {
			return addProperty("style", style);
		}

		public String toColV(Object arg) {
			return colType.toColV(arg);
		}

		public String toColF(Object arg) {
			return colType.toColF(arg);
		}

		public String toColF(String format, Object arg) {
			return colType.toColF(format, arg);
		}
	}
	
	@Getter
	@AllArgsConstructor
	@JsonInclude(NON_NULL)
	public static class Col {
		@NonNull
		private Object v;
		private String f;
	}
	
	@Getter
	@NoArgsConstructor
	@JsonInclude(NON_NULL)
	public static class Row {
		@NonNull
		private List<Col> c = new ArrayList<>();

		public Row(Col[] cols) {
			requireNonNull(cols);
			this.c = asList(cols);
		}

		public void addCol(Col col) {
			requireNonNull(col);
			c.add(col);
		}
	}
	
	@NonNull
	private List<ColDef> cols;
	@NonNull
	private List<Row> rows = new ArrayList<>();

	public GChartDataTable(ColDef[] cols) {
		requireNonNull(cols);
		this.cols = asList(cols);
	}

	/**
	 * 
	 * @param	rows	the 'v' value of {@link GChartDataTable#Col} class contained in this argument
	 * 					can be set to an actual Java object and it shall be converted automatically
	 * 					to its corresponding chart's value, e.g. a Java LocalDate object of
	 * 					1 Jan 1980 will be converted to a string 'new Date(1980, 0, 1)'.
	 */
	public GChartDataTable(ColDef[] cols, Row[] rows) {
		this(cols);
		requireNonNull(rows);
		stream(rows).forEach(this::addRow);
	}
	
	public static GChartDataTable of(Function<Object, ColDef[]> toColDefs, Function<Object, Row> toRow, List<?> vizObjs) {
		requireNonNull(vizObjs);
		if (vizObjs.isEmpty()) {
			throw new RuntimeException("List argument can not be empty!");
		}
		return new GChartDataTable(toColDefs.apply(vizObjs.get(0)), vizObjs.stream().map(toRow).toArray(Row[]::new));
	}
	
	private void addRow(Row row) {
//		if (row.getC().size() != cols.size()) {
//			throw new RuntimeException("Row contains incorrect number of columns!");
//		} else {
			rows.add(new Row(range(0, row.getC().size()).mapToObj(i -> convertIfNeeded(i, row.getC().get(i))).toArray(Col[]::new)));
//		}
	}
	
	private Col convertIfNeeded(int i, Col col) {
		ColDef colDef = cols.get(i);
		return new Col(colDef.toColV(col.getV())
			, col.getF() == null ? colDef.toColF(col.getV()) : colDef.toColF(col.getF(), col.getV()));  // if null, use the default format
	}
	
}
