package au.com.iag.viz.dao.mapper;

import au.com.iag.viz.dao.dto.SrcSysBusDto;
import au.com.iag.viz.dao.model.SrcSysBus;

public class SrcSysBusMapper {
    public static SrcSysBus toEntity(SrcSysBusDto dto) {
        return new SrcSysBus(dto.getId(), dto.getSsbReference(), dto.getBusinessTypeCode(), dto.getHoldingBusinessId(), dto.getVersion(), dto.getStatusCode(),
            dto.getDisplayLevel2(), dto.getStartDate(), dto.getEndDate(), dto.getTxnId(), dto.getTxnTypeCode(), dto.getTxnSubTypeCode(), dto.getUserId());
    }

    public static SrcSysBusDto toDto(SrcSysBus srcSysBus) {
    	return new SrcSysBusDto(srcSysBus.getId(), srcSysBus.getSsbReference(), srcSysBus.getBusinessTypeCode(), srcSysBus.getHoldingBusinessId(), srcSysBus.getVersion(), srcSysBus.getStatusCode(),
            srcSysBus.getDisplayLevel2(), srcSysBus.getStartDate(), srcSysBus.getEndDate(), srcSysBus.getTxnId(), srcSysBus.getTxnTypeCode(), srcSysBus.getTxnSubTypeCode(), srcSysBus.getUserId());
    }
}
