package au.com.iag.viz.dao.mapper;

import static au.com.im30.viz.util.DateUtil.dateToLocalDate;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.jdbc.core.RowMapper;

import au.com.iag.viz.dao.model.SrcSysBus;
import au.com.im30.viz.dao.model.Asset;

public class SrcSysBusRowMapper implements RowMapper<SrcSysBus> {

    @Override
    public SrcSysBus mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        long id = resultSet.getLong("src_sys_bus_id");
        String ssbReference = resultSet.getString("ssbreference");
        String businessTypeCode = resultSet.getString("business_type_cde");
        String holdingBusinessId = resultSet.getString("holding_business_id");
        int version = resultSet.getInt("version");
        String statusCode = resultSet.getString("lobstatus_cde");
        String displayLevel2 = resultSet.getString("lobdisplaylevel2");
        LocalDate startDate = dateToLocalDate(resultSet.getDate("start_date"));
        LocalDate endDate = dateToLocalDate(resultSet.getDate("end_date"));
        long txnId = resultSet.getLong("transaction_id");
        String txnTypeCode = resultSet.getString("tran_type_cde");
        String txnSubTypeCode = resultSet.getString("tran_subtype_cde");
        String userId = resultSet.getString("user_id");
        return new SrcSysBus(id, ssbReference, businessTypeCode, holdingBusinessId, version, statusCode,
            displayLevel2, startDate, endDate, txnId, txnTypeCode, txnSubTypeCode, userId);
    }
}
