/*
Copyright (c) 2023 Ferry Ie. All rights reserved.
*/

package au.com.im30.viz.dao.mapper;

import static au.com.im30.viz.util.DateUtil.dateToLocalDate;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.jdbc.core.RowMapper;

import au.com.im30.viz.dao.model.Asset;

public class AssetRowMapper implements RowMapper<Asset> {

    @Override
    public Asset mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        int id = resultSet.getInt("asset_id");
        String name = resultSet.getString("name");
        String description = resultSet.getString("description");
        LocalDate startDate = dateToLocalDate(resultSet.getDate("start_date"));
        LocalDate endDate = dateToLocalDate(resultSet.getDate("end_date"));
        return new Asset(id, name, description, startDate, endDate);
    }
}