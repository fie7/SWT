/*
Copyright (c) 2023 Ferry Ie. All rights reserved.
*/

package au.com.im30.viz.controller;

import static java.time.LocalDate.of;
import static java.time.LocalDate.parse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import au.com.im30.viz.model.GChartDataTable;
import au.com.im30.viz.model.GChartDataTable.Col;
import au.com.im30.viz.model.GChartDataTable.ColDef;
import au.com.im30.viz.model.GChartDataTable.ColType;
import au.com.im30.viz.model.GChartDataTable.Row;
import au.com.im30.viz.model.Politician;
import au.com.im30.viz.util.DateUtil;

@RestController
public class TestDataTableController {

	@GetMapping("/politicians")
	public List<Politician> getPoliticians() {
		return new ArrayList<>(Arrays.asList(new Politician[] {
			new Politician("President", "George Washington", new GregorianCalendar(1789, 3, 30).getTime(), new GregorianCalendar(1797, 2, 4).getTime()),
			new Politician("President", "John Adam", new GregorianCalendar(1797, 2, 4).getTime(), new GregorianCalendar(1801, 2, 4).getTime()),			
			new Politician("President", "Thomas Jefferson", new GregorianCalendar(1801, 2, 4).getTime(), new GregorianCalendar(1809, 2, 4).getTime())		
		}));
	}

	@GetMapping("/empty")
	public GChartDataTable empty() {
		return null;
	}

	@GetMapping("/politiciansDt")
	public GChartDataTable getPoliticiansDtTest() {
		return GChartDataTable.of(o -> new ColDef[] {
				new ColDef("Position", null, ColType.STRING)
				, new ColDef("Name", null, ColType.STRING)
				, new ColDef("Start", null, ColType.DATE)
				, new ColDef("End", null, ColType.DATE)				
			}, o -> Optional.of(o).map(Politician.class::cast).map(p -> new Row(new Col[] {
					new Col(p.getPosition(), null)
					, new Col(p.getName(), null)
					, new Col(DateUtil.dateToLocalDate(p.getStartDate()), null)
					, new Col(DateUtil.dateToLocalDate(p.getEndDate()), null)
				})).get()
			, getPoliticians());
	}

	@GetMapping("/politiciansDtTest")
	public GChartDataTable getPoliticiansDt() {
		return new GChartDataTable(new ColDef[] {
				new ColDef("Position", null, ColType.STRING)
				, new ColDef("Name", null, ColType.STRING)
				, new ColDef("Start", null, ColType.DATE)
				, new ColDef("End", null, ColType.DATE)
//				, new ColDef(null, null, ColType.NUMBER, null).addRole(ColumnRole.INTERVAL)
//				, new ColDef(null, null, ColType.NUMBER, null).addRole(ColumnRole.INTERVAL)
			}, new Row[] {
				new Row(new Col[] {
					new Col("President", null)  // default format
					, new Col("George Washington", null)  // default format
					, new Col(parse("1789-04-30"), null)  // default format
					, new Col(parse("1797-03-04"), null)  // default format
				})
				, new Row(new Col[] {
						new Col("President", null)  // default format
						, new Col("Georgie Doggy", null)  // default format
						, new Col(parse("1797-03-04"), null)  // default format
						, new Col(parse("1797-03-04"), null)  // default format
					})
				, new Row(new Col[] {
						new Col("President", null)  // default format
						, new Col("Johny Doggy", null)  // default format
						, new Col(parse("1797-03-04"), null)  // default format
						, new Col(parse("1797-03-04"), null)  // default format
					})
				, new Row(new Col[] {
						new Col("President", null)  // default format
						, new Col("Ronnie Doggy", null)  // default format
						, new Col(parse("1797-03-04"), null)  // default format
						, new Col(parse("1797-03-04"), null)  // default format
					})
				, new Row(new Col[] {
						new Col("President", null)
						, new Col("John Adams", null)
						, new Col(parse("1797-03-04"), null)
						, new Col(parse("1801-03-04"), null)
//						, new Col(1798, null)
//						, new Col(1799, null)
				})
				, new Row(new Col[] {
						new Col("President", null)
						, new Col("Thomas Jefferson", null)
						, new Col(parse("1801-03-04"), null)
						, new Col(parse("1809-03-04"), null)
				})
				, new Row(new Col[] {
						new Col("Vice President", null)
						, new Col("John Adams", null)
						, new Col(parse("1789-04-21"), null)
						, new Col(parse("1797-03-04"), null)
				})
				, new Row(new Col[] {
						new Col("Vice President", null)
						, new Col("Thomas Jefferson", null)
						, new Col(parse("1797-03-04"), null)
						, new Col(parse("1801-03-04"), null)
				})
				, new Row(new Col[] {
						new Col("Vice President", null)
						, new Col("Aaron Burr", null)
						, new Col(parse("1801-03-04"), null)
						, new Col(parse("1805-03-04"), null)
				})
				, new Row(new Col[] {
						new Col("Vice President", null)
						, new Col("George Clinton", null)
						, new Col(parse("1805-03-04"), null)
						, new Col(parse("1812-04-20"), null)
				})
				, new Row(new Col[] {
						new Col("Secretary of State", null)
						, new Col("John Jay", null)
						, new Col(of(1789, 9, 25), null)
						, new Col(of(1790, 3, 22), null)
				})
				, new Row(new Col[] {
						new Col("Secretary of State", null)
						, new Col("Thomas Jefferson", null)
						, new Col(of(1790, 3, 22), null)
						, new Col(of(1793, 12, 31), null)
				})
				, new Row(new Col[] {
						new Col("Secretary of State", null)
						, new Col("Edmund Randolph", null)
						, new Col(of(1794, 1, 2), null)
						, new Col(of(1795, 8, 20), null)
				})
				, new Row(new Col[] {
						new Col("Secretary of State", null)
						, new Col("Timothy Pickering", null)
						, new Col(of(1795, 8, 20), null)
						, new Col(of(1800, 5, 12), null)
				})
				, new Row(new Col[] {
						new Col("Secretary of State", null)
						, new Col("Charles Lee", null)
						, new Col(of(1800, 5, 13), null)
						, new Col(of(1800, 6, 5), null)
				})
				, new Row(new Col[] {
						new Col("Secretary of State", null)
						, new Col("John Marshall", null)
						, new Col(of(1800, 6, 13), null)
						, new Col(of(1801, 3, 4), null)
				})
				, new Row(new Col[] {
						new Col("Secretary of State", null)
						, new Col("Levi Lincoln", null)
						, new Col(of(1801, 3, 5), null)
						, new Col(of(1801, 5, 1), null)
				})
				, new Row(new Col[] {
						new Col("Secretary of State", null)
						, new Col("James Madison", null)
						, new Col(of(1801, 5, 2), null)
						, new Col(of(1809, 3, 3), null)
				})
			}
		);
	}
}
