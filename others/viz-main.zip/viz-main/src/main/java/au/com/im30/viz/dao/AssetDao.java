/*
Copyright (c) 2023 Ferry Ie. All rights reserved.
*/

package au.com.im30.viz.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import au.com.im30.viz.dao.mapper.AssetRowMapper;
import au.com.im30.viz.dao.model.Asset;

@Repository
public class AssetDao {

    private final NamedParameterJdbcTemplate template;
    private final AssetQueries queries;
    private final RowMapper<Asset> rowMapper;

    @Autowired
    public AssetDao(NamedParameterJdbcTemplate template, AssetQueries queries) {
        this.template = template;
        this.rowMapper = new AssetRowMapper();
        this.queries = queries;
    }

    public Stream<Asset> findAll() {
        String sql = queries.getFindAll();
        return template.query(sql, (Map<String, ?>) null, rowMapper).stream();
    }

    public Stream<Asset> findAllById(long id) {
        String sql = queries.getFindAllById();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("id", id);
        return template.query(sql, paramMap, rowMapper).stream();
    }

}