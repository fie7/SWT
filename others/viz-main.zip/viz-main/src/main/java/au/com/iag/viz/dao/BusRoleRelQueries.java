package au.com.iag.viz.dao;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class BusRoleRelQueries {

    @Value("${bus_role_rel.query.find.all.by.id}")
    private String findAllById;

    public String getFindAllById() {
        return findAllById;
    }
}