package au.com.iag.viz.dao.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BusRoleRelDto {
	private long id;
    private int version;
	private String PartyBusinessRoleCode;
	private LocalDate startDate;
	private LocalDate endDate;
	private long txnId;
	private String txnTypeCode;
	private String txnSubTypeCode;
	private String userId;
}
