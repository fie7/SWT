package au.com.iag.viz.dao.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import au.com.iag.viz.dao.SrcSysBusDao;
import au.com.iag.viz.dao.dto.SrcSysBusDto;
import au.com.iag.viz.dao.mapper.SrcSysBusMapper;
import au.com.iag.viz.dao.model.SrcSysBus;

@Service
public class SrcSysBusService {

    private final SrcSysBusDao dao;

    @Autowired
    public SrcSysBusService(SrcSysBusDao dao) {
        this.dao = dao;
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<SrcSysBusDto> findAllById(long id) {
        Stream<SrcSysBus> stream = dao.findAllById(id);
        return stream.map(SrcSysBusMapper::toDto).collect(Collectors.toList());
    }
}