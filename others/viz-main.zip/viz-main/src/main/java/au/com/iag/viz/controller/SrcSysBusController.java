package au.com.iag.viz.controller;

import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import au.com.iag.viz.dao.dto.SrcSysBusDto;
import au.com.iag.viz.dao.service.SrcSysBusService;
import au.com.im30.viz.dao.dto.AssetDto;
import au.com.im30.viz.model.GChartDataTable;
import au.com.im30.viz.model.GChartDataTable.Col;
import au.com.im30.viz.model.GChartDataTable.ColDef;
import au.com.im30.viz.model.GChartDataTable.ColType;
import au.com.im30.viz.model.GChartDataTable.Row;
import au.com.im30.viz.util.DateUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@RestController
public class SrcSysBusController {

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    private static class MinMax {
        private LocalDate min;
        private LocalDate max;
        
        public LocalDate getMin() {
            return min;
        }

        public void setMin(LocalDate min) {
            this.min = min;
        }

        public LocalDate getMax() {
            return max;
        }

        public void setMax(LocalDate max) {
            this.max = max;
        }

        private LocalDate min(LocalDate thisDate, LocalDate thatDate) {
            // null is treated less than any date
            if (thisDate == null) {
                return thisDate;
            } else if (thatDate == null) {
                return thatDate;
            }
            if (thisDate.isBefore(thatDate)) {
                return thisDate;
            } else {
                return thatDate;
            }
        }
        
        private LocalDate max(LocalDate thisDate, LocalDate thatDate) {
            if (thisDate == null) {
                return thatDate;
            } else if (thatDate == null) {
                return thisDate;
            }
            if (thisDate.isAfter(thatDate)) {
                return thisDate;
            } else {
                return thatDate;
            }
        }

        public MinMax accumulate(AssetDto asset) {
            LocalDate startDate;
            LocalDate endDate;
            
            if (min == null) {  // first comparison
                min = min(asset.getStartDate(), asset.getEndDate());
                max = max(asset.getStartDate(), asset.getEndDate());
            } else {
                min = min(min, min(asset.getStartDate(), asset.getEndDate()));
                max = max(max, max(asset.getStartDate(), asset.getEndDate()));
            }
            return this;
        }
        
        public MinMax combine(MinMax mm) {
            min = min(min, mm.getMin());
            max = max(max, mm.getMax());
            return this;
        }
    }

    private final SrcSysBusService service;

    public SrcSysBusController(SrcSysBusService service) {
        this.service = service;
    }

    @GetMapping("/businesses")
    public List<SrcSysBusDto> findAllById(@RequestParam(required = false) Long id) {
    	if (ofNullable(id).isPresent()) {
    		return service.findAllById(id);
    	} else {
    		return Collections.emptyList();
    	}
    }
    
    private String getDateRange(SrcSysBusDto dto) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        boolean openEndDate = dto.getEndDate().isEqual(LocalDate.of(9999, 12, 31));
        return sdf.format(DateUtil.localDateToDate(dto.getStartDate())) + " - " + (openEndDate ? "\u221E" : sdf.format(DateUtil.localDateToDate(dto.getEndDate()))); 
    }
    
    private String getDuration(SrcSysBusDto dto) {
        if (dto.getEndDate().isEqual(LocalDate.of(9999, 12, 31))) {
            return "\u221E";
        }
        Period diff = Period.between(dto.getStartDate(), dto.getEndDate());
        int diffYears = diff.getYears();
        int diffMonths = diff.getMonths();
        int diffDays = diff.getDays();
        return (diffYears > 0 ? diffYears + " year(s) " : "") + (diffMonths > 0 ? diffMonths + " month(s) " : "") + (diffDays > 0 ? diffDays + " day(s) " : ""); 
    }
    
    private String generateTooltip(SrcSysBusDto dto) {
        String template = "<b>SSB reference: </b>%s<div class='google-visualization-tooltip-separator'></div><b>%s </b>[%s]<br/>"
            + "<b>Duration: </b>%s<br/><div class='google-visualization-tooltip-separator'></div>"
            + "<b>Holding business ID: </b>%s<br/><b>Business type: </b>%s<br/><b>Version: </b>%s<br/><b>User: </b>%s";
        return String.format(template, dto.getSsbReference(), dto.getStatusCode(), getDateRange(dto), getDuration(dto), dto.getHoldingBusinessId(), dto.getBusinessTypeCode(), dto.getVersion(), dto.getUserId());
    }
    
    private AssetDto toAssetDto(SrcSysBusDto dto) {
        return new AssetDto((int) dto.getId(), dto.getSsbReference(), dto.getStatusCode(), dto.getStartDate(), dto.getEndDate(), generateTooltip(dto), false);
    }

    private List<AssetDto> toAssetDtos(List<SrcSysBusDto> dtos) {
        return dtos.stream().map(this::toAssetDto).collect(Collectors.toList());
    }
    
    private List<AssetDto> addHeader(List<AssetDto> dtos) {
        long plotableCount = dtos.stream().filter(d -> d.getEndDate().isAfter(d.getStartDate()) && !d.getEndDate().isEqual(LocalDate.of(9999, 12, 31)))
            .count();
        if (plotableCount > 0) {
            return dtos;  // no change
        } else {
            // find min and max excl. open dates
            List<AssetDto> dtoss = dtos.stream().map(d -> {
                LocalDate startDate = (d.getStartDate().isEqual(LocalDate.of(9999, 12, 31))) ? d.getEndDate() : d.getStartDate();
                LocalDate endDate = (d.getEndDate().isEqual(LocalDate.of(9999, 12, 31))) ? d.getStartDate() : d.getEndDate();
                return new AssetDto(d.getId(), d.getName(), d.getDescription(), startDate, endDate);    
            }).collect(Collectors.toList());
            List<AssetDto> dtosz = dtoss.stream().filter(d -> !d.getStartDate().isEqual(LocalDate.of(9999, 12, 31)) && !d.getEndDate().isEqual(LocalDate.of(9999, 12, 31))).collect(Collectors.toList());
            MinMax mm = dtosz.stream().collect(MinMax::new, MinMax::accumulate, MinMax::combine);
            /*
            MinMax mm = dtos.stream().map(d -> {
                LocalDate startDate = (d.getStartDate().isEqual(LocalDate.of(9999, 12, 31))) ? d.getEndDate() : d.getStartDate();
                LocalDate endDate = (d.getEndDate().isEqual(LocalDate.of(9999, 12, 31))) ? d.getStartDate() : d.getEndDate();
                return new AssetDto(d.getId(), d.getName(), d.getDescription(), startDate, endDate);    
            }).filter(d -> !d.getStartDate().isEqual(LocalDate.of(9999, 12, 31)) && !d.getEndDate().isEqual(LocalDate.of(9999, 12, 31)))
                .collect(MinMax::new, MinMax::accumulate, MinMax::combine);
            */
            // create a new asset for the header
            //AssetDto dto = new AssetDto(0, "", "", LocalDate.of(mm.getMin().getYear(), 1, 1), LocalDate.of(mm.getMax().getYear(), 12, 31));
            AssetDto dto = new AssetDto(0, "", "", mm.getMin().plusDays(-1), mm.getMax().plusDays(1));
            return Stream.concat(Stream.of(dto), dtos.stream()).collect(Collectors.toList());
        }
    }

    private List<AssetDto> addOpenDateRowForCharting(List<AssetDto> dtos) {
/*
        long plotableCount = dtos.stream().filter(d -> d.getEndDate().isAfter(d.getStartDate()) && !d.getEndDate().isEqual(LocalDate.of(9999, 12, 31)))
            .count();
        if (plotableCount > 0) {
            return dtos;  // no change
        } else {
*/
            Optional<AssetDto> dto = dtos.stream().filter(d -> d.getEndDate().isEqual(LocalDate.of(9999, 12, 31))).findFirst();
            if (dto.isPresent()) {
                // create a new row to represent open dated record
                // also handle bad data for a scenario where there are records running in parrallel with this open dated one and their start dates are >= open end dated record's start date + 1 year (for charting purposes, we only add 1 year from start) 
                MinMax mm = dtos.stream().map(d -> {
                    LocalDate startDate = (d.getStartDate().isEqual(LocalDate.of(9999, 12, 31))) ? d.getEndDate() : d.getStartDate();
                    LocalDate endDate = (d.getEndDate().isEqual(LocalDate.of(9999, 12, 31))) ? d.getStartDate() : d.getEndDate();
                    return new AssetDto(d.getId(), d.getName(), d.getDescription(), startDate, endDate);    
                }).filter(d -> !d.getStartDate().isEqual(LocalDate.of(9999, 12, 31)) && !d.getEndDate().isEqual(LocalDate.of(9999, 12, 31)))
                    .collect(MinMax::new, MinMax::accumulate, MinMax::combine);

                LocalDate endDateForCharting = mm.getMax().isAfter(dto.get().getStartDate().plusYears(1)) ? mm.getMax() : dto.get().getStartDate().plusYears(1);
                AssetDto newDto = new AssetDto(0, dto.get().getName(), dto.get().getDescription(), dto.get().getStartDate(), endDateForCharting, dto.get().getTooltip(), true);
                return Stream.concat(Stream.of(newDto), dtos.stream()).collect(Collectors.toList());
            } else {
                return dtos;
            }
//        }
    }

    private AssetDto enhanceName(AssetDto asset, List<String> names) {
    	if (names.stream().filter(n -> n.equals(asset.getName())).findFirst().isPresent()) {
    		return new AssetDto(asset.getId(), asset.getName() + " \u221E", asset.getDescription(), asset.getStartDate(), asset.getEndDate(), asset.getTooltip(), asset.isDummy());
    	} else {
    		return asset;
    	}
    }

    private List<AssetDto> enhanceNamesForOpenEndDateAssets(List<AssetDto> assets) {
    	List<String> openEndDateAssetNames = assets.stream().filter(a -> a.getEndDate().equals(LocalDate.of(9999, 12, 31)))
    		.map(a -> a.getName()).collect(Collectors.toList());
    	return assets.stream().map(a -> {return enhanceName(a, openEndDateAssetNames);}).collect(Collectors.toList());
    }

    public List<AssetDto> getDtosForCharting(Long id) {
        return enhanceNamesForOpenEndDateAssets(addOpenDateRowForCharting(toAssetDtos(findAllById(id).stream().filter(d -> d.getEndDate().isAfter(d.getStartDate())).collect(Collectors.toList()))));
    }

    @GetMapping("/businessesDt")
    public GChartDataTable toDataTable(@RequestParam(required = false) Long id) {
    	//List<AssetDto> assets = enhanceNamesForOpenEndDateAssets(addHeader(toAssetDtos(findAllById(id))));
        //List<AssetDto> assets = enhanceNamesForOpenEndDateAssets(toAssetDtos(findAllById(id)));
        //List<AssetDto> assets = enhanceNamesForOpenEndDateAssets(addOpenDateRowForCharting(toAssetDtos(findAllById(id))));
        List<AssetDto> assets = enhanceNamesForOpenEndDateAssets(addOpenDateRowForCharting(toAssetDtos(findAllById(id).stream().filter(d -> d.getEndDate().isAfter(d.getStartDate())).collect(Collectors.toList()))));

    	if (assets.size() > 0) {
			return GChartDataTable.of(o -> new ColDef[] {
					new ColDef("Asset Name", null, ColType.STRING)
					, new ColDef("Description", null, ColType.STRING)
					, new ColDef("Start", null, ColType.DATE)
					, new ColDef("End", null, ColType.DATE)				
				}, o -> of(o).map(AssetDto.class::cast).map(a -> new Row(new Col[] {
						new Col(a.getName(), null)
						, new Col(a.getDescription(), null)
						, new Col(a.getStartDate(), null)
						, new Col(a.getEndDate(), null)
					})).get()
				, assets);
    	} else {
    		return null;
    	}
    }

}