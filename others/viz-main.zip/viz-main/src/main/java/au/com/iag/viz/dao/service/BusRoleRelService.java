package au.com.iag.viz.dao.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import au.com.iag.viz.dao.BusRoleRelDao;
import au.com.iag.viz.dao.dto.BusRoleRelDto;
import au.com.iag.viz.dao.mapper.BusRoleRelMapper;
import au.com.iag.viz.dao.model.BusRoleRel;

@Service
public class BusRoleRelService {

    private final BusRoleRelDao dao;

    @Autowired
    public BusRoleRelService(BusRoleRelDao dao) {
        this.dao = dao;
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<BusRoleRelDto> findAllById(long id) {
        Stream<BusRoleRel> stream = dao.findAllById(id);
        return stream.map(BusRoleRelMapper::toDto).collect(Collectors.toList());
    }
}