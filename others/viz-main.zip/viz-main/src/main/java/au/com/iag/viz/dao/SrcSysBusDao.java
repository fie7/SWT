package au.com.iag.viz.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import au.com.iag.viz.dao.mapper.SrcSysBusRowMapper;
import au.com.iag.viz.dao.model.SrcSysBus;

@Repository
public class SrcSysBusDao {

    private final NamedParameterJdbcTemplate template;
    private final SrcSysBusQueries queries;
    private final RowMapper<SrcSysBus> rowMapper;

    @Autowired
    public SrcSysBusDao(NamedParameterJdbcTemplate template, SrcSysBusQueries queries) {
        this.template = template;
        this.rowMapper = new SrcSysBusRowMapper();
        this.queries = queries;
    }

    public Stream<SrcSysBus> findAllById(long id) {
        String sql = queries.getFindAllById();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("id", id);
        return template.query(sql, paramMap, rowMapper).stream();
    }

}