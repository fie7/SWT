package au.com.iag.viz.dao.mapper;

import au.com.iag.viz.dao.dto.BusRoleRelDto;
import au.com.iag.viz.dao.model.BusRoleRel;

public class BusRoleRelMapper {
    public static BusRoleRel toEntity(BusRoleRelDto dto) {
        return new BusRoleRel(dto.getId(), dto.getVersion(), dto.getPartyBusinessRoleCode(), dto.getStartDate(),
            dto.getEndDate(), dto.getTxnId(), dto.getTxnTypeCode(), dto.getTxnSubTypeCode(), dto.getUserId());
    }

    public static BusRoleRelDto toDto(BusRoleRel busRoleRel) {
    	return new BusRoleRelDto(busRoleRel.getId(), busRoleRel.getVersion(), busRoleRel.getPartyBusinessRoleCode(), busRoleRel.getStartDate(),
    	    busRoleRel.getEndDate(), busRoleRel.getTxnId(), busRoleRel.getTxnTypeCode(), busRoleRel.getTxnSubTypeCode(), busRoleRel.getUserId());
    }
}
