package au.com.iag.viz.dao.mapper;

import static au.com.im30.viz.util.DateUtil.dateToLocalDate;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.jdbc.core.RowMapper;

import au.com.iag.viz.dao.model.BusRoleRel;

public class BusRoleRelRowMapper implements RowMapper<BusRoleRel> {

    @Override
    public BusRoleRel mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        long id = resultSet.getLong("busi_role_rel_id");
        int version = resultSet.getInt("version");
        String partyBusinessRoleCode = resultSet.getString("party_bus_role_cde");
        LocalDate startDate = dateToLocalDate(resultSet.getDate("start_date"));
        LocalDate endDate = dateToLocalDate(resultSet.getDate("end_date"));
        long txnId = resultSet.getLong("transaction_id");
        String txnTypeCode = resultSet.getString("tran_type_cde");
        String txnSubTypeCode = resultSet.getString("tran_subtype_cde");
        String userId = resultSet.getString("user_id");
        return new BusRoleRel(id, version, partyBusinessRoleCode, startDate, endDate, txnId, txnTypeCode, txnSubTypeCode, userId);
    }
}
