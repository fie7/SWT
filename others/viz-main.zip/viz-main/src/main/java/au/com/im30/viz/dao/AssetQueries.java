/*
Copyright (c) 2023 Ferry Ie. All rights reserved.
*/

package au.com.im30.viz.dao;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AssetQueries {

    @Value("${asset.query.find.all}")
    private String findAll;

    @Value("${asset.query.find.all.by.id}")
    private String findAllById;

    public String getFindAll() {
        return findAll;
    }

    public String getFindAllById() {
        return findAllById;
    }
}