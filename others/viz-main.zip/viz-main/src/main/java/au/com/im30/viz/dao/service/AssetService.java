/*
Copyright (c) 2023 Ferry Ie. All rights reserved.
*/

package au.com.im30.viz.dao.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import au.com.im30.viz.dao.AssetDao;
import au.com.im30.viz.dao.dto.AssetDto;
import au.com.im30.viz.dao.mapper.AssetMapper;
import au.com.im30.viz.dao.model.Asset;

@Service
public class AssetService {

    private final AssetDao dao;

    @Autowired
    public AssetService(AssetDao dao) {
        this.dao = dao;
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<AssetDto> findAll() {
        Stream<Asset> stream = dao.findAll();
        return stream.map(AssetMapper::toDto).collect(Collectors.toList());
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<AssetDto> findAllById(long id) {
        Stream<Asset> stream = dao.findAllById(id);
        return stream.map(AssetMapper::toDto).collect(Collectors.toList());
    }
}