package au.com.im30.viz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VizApplicationTests {

	@Test
	void contextLoads() {
	}

}
