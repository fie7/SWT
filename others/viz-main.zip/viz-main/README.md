# viz
Data visualizer for records with start and end dates
